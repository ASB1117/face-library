window.baseBooks = [
  {
    "serialNo": 1,
    "bookNo": "N-1/750",
    "title": "രാത്രി 12 നു ശേഷം",
    "author": "അഖിൽ പി ധർമ്മജൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 2,
    "bookNo": "N-2/188",
    "title": "ലന്തൻ ബത്തേരിയിലെ ലുത്തിനിയകൾ ",
    "author": "എൻ.എസ് മാധവൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 3,
    "bookNo": "N-3/189",
    "title": "എന്മകജെ ",
    "author": "അംബികസൂതൻ മാങ്ങാട് ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 4,
    "bookNo": "N-4/190",
    "title": "കൈച്ചുമ്മ ",
    "author": "സാബി തെക്കേപുറം ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 5,
    "bookNo": "N-5/191",
    "title": "അഖില ലോക ആടുകമ്പനി ",
    "author": "മജീദ് സേയ്ദ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 6,
    "bookNo": "N-6/192",
    "title": "ചെങ്കിസ്കാന്റെ കുതിരകൾ ",
    "author": "വിനു ഇബ്രാഹിം ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 7,
    "bookNo": "N-7/163",
    "title": "ഇന്ദുലേഖ",
    "author": "ഓ ചന്തുമേനോൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 8,
    "bookNo": "N-8/552",
    "title": " നേരം നുണയും",
    "author": "എൻ പ്രഭാകരൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 9,
    "bookNo": "N-9/528",
    "title": "പ്രേം പാറ്റ ബഷീർ",
    "author": " ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 10,
    "bookNo": "N-10/165",
    "title": "ഖസാക്കിന്റെ ഇതിഹാസം",
    "author": "ഒ വി വിജയൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 11,
    "bookNo": "N-11/739",
    "title": "ആടുജീവിതം",
    "author": "ബെന്യാമിൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 12,
    "bookNo": "N-12/757",
    "title": "ആൽകെമിസ്റ്",
    "author": "പൗലോ കൊയ്‌ലോ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 13,
    "bookNo": "N-13/195",
    "title": "മീശ ",
    "author": "എസ്.ഹരീഷ് ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 14,
    "bookNo": "N-14/167",
    "title": "പാത്തുമ്മയുടെ ആട്",
    "author": "വൈക്കം മുഹമ്മദ് ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 15,
    "bookNo": "N-15/738",
    "title": "ആടുജീവിതം",
    "author": "ബെന്യാമിൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 16,
    "bookNo": "N-16/196",
    "title": "നൂർ സിംഹസങ്ങൾ ",
    "author": "ജയമോഹൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 17,
    "bookNo": "N-17/249",
    "title": "മഞ്ഞ്",
    "author": "എം ടി",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 18,
    "bookNo": "N-18/531",
    "title": "മാന്ത്രിക പൂച്ച",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 19,
    "bookNo": "N-19/527",
    "title": "മുച്ചീട്ടു കളിക്കാരന്റെ മകൾ",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 20,
    "bookNo": "N-20/198",
    "title": "ഇനി ഞാൻ ഉറക്കട്ടെ ",
    "author": "പി.കെ ബാലകൃഷ്ണൻ  ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 21,
    "bookNo": "N21/384",
    "title": "ഇരുൾ സന്ദർശനങ്ങൾ",
    "author": "പി കെ രാജശേഖരൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 22,
    "bookNo": "N-22/173",
    "title": "മാന്ത്രിക പൂച്ച",
    "author": "വൈക്കം മുഹമ്മദ് ബഷീർ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 23,
    "bookNo": "N23/300",
    "title": "ക്ഷണിക്കപ്പെടാതെ",
    "author": "ഫ്യുഡോർ ഡോസ്റ്റോയേഫ്സ്ക്കി",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 24,
    "bookNo": "N-24/199",
    "title": "രാത്രിയിൽ എല്ലാ രക്ക്തത്തിനും നിറം കറുപ്പ് ",
    "author": "ഡോവിഡ് ദിലോപ് രാതമാകരൻ  ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 25,
    "bookNo": "N-25/526",
    "title": "മുച്ചീട്ടു കളിക്കാരന്റെ മകൾ",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 26,
    "bookNo": "N-26/200",
    "title": "അഗ്നീസാക്ഷി ",
    "author": "ലളിതാബിക അന്തർജനം ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 27,
    "bookNo": "N-27/176",
    "title": "ആടുജീവിതം",
    "author": "ബെന്യാമിൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 28,
    "bookNo": "N-28/114",
    "title": "ആടുജീവിതം",
    "author": "ബെന്യാമിൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 29,
    "bookNo": "N-29/393",
    "title": "അയൽക്കാർ ",
    "author": "പി. കേശവദേവ് ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 30,
    "bookNo": "N-30/394",
    "title": "തിളർക്കമാർന്ന ഒരായിരം സൂര്യന്മാർ ",
    "author": "ഖാലിദ് ഹൊസൈനി/രമാ മേനോൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 31,
    "bookNo": "N-31/521",
    "title": "സ്ഥലത്തെ പ്രധാന ദിവ്യൻ",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 32,
    "bookNo": "N-32/763",
    "title": "മയ്യഴിപ്പുഴയുടെ തീരങ്ങളിൽ",
    "author": "എം മുകുന്ദൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 33,
    "bookNo": "N-33/523",
    "title": "ഒരു പോങ്ങ റേഷൻ അരി",
    "author": "മജീദ് മൂത്തേടത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 34,
    "bookNo": "N-34/179",
    "title": "ഹിപ്പി ",
    "author": "പൗലോ കൊയ്‌ലോ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 35,
    "bookNo": "N-35/201",
    "title": "കോമ ",
    "author": "അൻവർ അബ്ദുല്ല",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 36,
    "bookNo": "N-36/202",
    "title": "ഹരിദ്വാരിൽ മണികൾ മുഴങ്ങുന്നു",
    "author": "എം. മുകുന്ദൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 37,
    "bookNo": "N-37/520",
    "title": "മതിലുകൾ",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 38,
    "bookNo": "N-38/203",
    "title": "വേരുകൾ ",
    "author": "മലയാറ്റൂർ രാമകൃഷ്ണൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 39,
    "bookNo": "N-39/518",
    "title": "ആനവാരിയും പൊൻ കുരിശും",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 40,
    "bookNo": "N-40/204",
    "title": "പിനോക്യോ ",
    "author": "കാർലോ കോലോദി/അനിത തമ്പി ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 41,
    "bookNo": "N-41/205",
    "title": "പെൺകുട്ടികളുടെ വീട്",
    "author": "സോണിയ റഫീഖ്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 42,
    "bookNo": "N-43/184",
    "title": "പൊനം ",
    "author": "കെ. എൻ. പ്രശാന്ത് ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 43,
    "bookNo": "N-44/185",
    "title": "തങ്കച്ചൻ മഞ്ഞക്കാരൻ ",
    "author": "എൻ.ശശിധരൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 44,
    "bookNo": "N-45/206",
    "title": "സ്‌കാവഞ്ചർ  ടി പ്രാണകുമാർ \nകൊലക്കേസ് അന്വേഷണം\n",
    "author": "ജി. ആർ. ഇന്ദുഗോപൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 45,
    "bookNo": "N-46/514",
    "title": "ഇനി...",
    "author": "മേലാൺ മൈ പൊന്നുച്ചാമി",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 46,
    "bookNo": "N-47/207",
    "title": "കല്യാണിയെന്നും ദാക്ഷായണിയെന്നും \nപേരായ രണ്ടു സ്ത്രീകളുടെ കഥ \n",
    "author": "ആർ. രാജശ്രീ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 47,
    "bookNo": "N-48/208",
    "title": "പെഡ്രോ പരാമോ ",
    "author": "ഹുവാൻ റൂൾഫോ /വിലാസിനി ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 48,
    "bookNo": "N-49/209",
    "title": "ഭാഗ്യ രേഖ ",
    "author": "ശിഹാബുദ്ധീൻ പോയ്‌ത്തും കടവ് ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 49,
    "bookNo": "N-50/210",
    "title": "എലിമിനേഷൻ റൗണ്ട് -കരിയർ ഫിക്ഫൻ ",
    "author": "ലിപിൻ രാജ്. MP/ലിങ്കു എബ്രഹാം ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 50,
    "bookNo": "N-51/211",
    "title": "മാസ്റ്റർ പീസ് ",
    "author": "ഫ്രാൻസിസ് നൊറോണ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 51,
    "bookNo": "N-52/212",
    "title": "ഇരുട്ടിന്റെ ഹൃദയം",
    "author": "ജോസഫ് കോൺറാഡ് ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 52,
    "bookNo": "N-53/213",
    "title": "ആരാച്ചാർ ",
    "author": "കെ ആർ മീര ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 53,
    "bookNo": "N-54/721",
    "title": "ഖബർ",
    "author": "കെ ആർ മീര",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 54,
    "bookNo": "N-55/722",
    "title": "ഖബർ",
    "author": "കെ ആർ മീര",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 55,
    "bookNo": "N-56/737",
    "title": "ആടുജീവിതം",
    "author": "ബെന്യാമിൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 56,
    "bookNo": "N-57/180",
    "title": "ലജ്ജ ",
    "author": "തസ്‌ലീമ നസ്‌റിൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 57,
    "bookNo": "N-58/164",
    "title": "ചെമ്മീൻ ",
    "author": "തകഴി ശിവശങ്കരപ്പിള്ള",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 58,
    "bookNo": "N-59/484",
    "title": "ഖബർ",
    "author": "കെ ആർ മീര",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 59,
    "bookNo": "N-60/482",
    "title": "ബോട്ടപകടം",
    "author": "രബീന്ദ്രനാഥ ടാഗോർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 60,
    "bookNo": "N-61/174",
    "title": "നിശബ്ദ സഞ്ചാരങ്ങൾ",
    "author": "ബെന്യാമിൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 61,
    "bookNo": "N-62/723",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 62,
    "bookNo": "N-63/724",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 63,
    "bookNo": "N-64/725",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 64,
    "bookNo": "N-65/726",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 65,
    "bookNo": "N-66/727",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 66,
    "bookNo": "N-67/728",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 67,
    "bookNo": "N-68/729",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 68,
    "bookNo": "N-69/730",
    "title": "ഖദീജ",
    "author": "നസീഫ് കലയത്ത്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 69,
    "bookNo": "N-70/745",
    "title": "ഒരിക്കൽ",
    "author": "എൻ മോഹൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 70,
    "bookNo": "N-71/746",
    "title": "ഒരിക്കൽ",
    "author": "എൻ മോഹൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 71,
    "bookNo": "N-72/747",
    "title": "ഒരിക്കൽ",
    "author": "എൻ മോഹൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 72,
    "bookNo": "N-73/764",
    "title": "ബാല്യകാലസഖി",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 73,
    "bookNo": "N-74/765",
    "title": "ബാല്യകാലസഖി",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 74,
    "bookNo": "N-75/767",
    "title": "പാത്തുമ്മായുടെ ആട്",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 75,
    "bookNo": "N-76/770",
    "title": "റാം c/o ആനന്ദി",
    "author": "അഖിൽ പി ധർമ്മജൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 76,
    "bookNo": "N-77/773",
    "title": "തിളർക്കമാർന്ന ഒരായിരം സൂര്യന്മാർ ",
    "author": "ഖാലിദ് ഹൊസൈനി/രമാ മേനോൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 77,
    "bookNo": "N-78/774",
    "title": "ജീൻവാൽജീൻ",
    "author": "വിക്തോർ ഹ്യൂഗോ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 78,
    "bookNo": "N-79/775",
    "title": "ന്റുപ്പുപ്പാക്കൊരാനേണ്ടാർന്നു !",
    "author": "ബഷീർ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 79,
    "bookNo": "N-80/776",
    "title": "പാത്തുമ്മയുടെ ആട് ",
    "author": "ബഷീർ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 80,
    "bookNo": "N-81/777",
    "title": "സൂസന്നയുടെ ഗ്രന്ഥപ്പുര ",
    "author": "അജയ് പി മങ്ങാട്ട്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 81,
    "bookNo": "N-82/779",
    "title": "ആടുജീവിതം ",
    "author": "ബെന്യാമിൻ ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 82,
    "bookNo": "N-83/780",
    "title": "പ്രവാസം",
    "author": "എം മുകുന്ദൻ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 83,
    "bookNo": "N-84/781",
    "title": "പാത്തുമ്മയുടെ ആട്",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 84,
    "bookNo": "N-85/782",
    "title": "ബാല്യകാലസഖി ",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 85,
    "bookNo": "N-86/783",
    "title": "മുച്ചീട്ടുകളിക്കാരന്റെ  മകൾ ",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 86,
    "bookNo": "N-87/784",
    "title": "ദി ജംഗ്‌ൾ",
    "author": "അപ്ടൻ സിൻക്ലെയർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 87,
    "bookNo": "N-88/792",
    "title": "SPUTINIK SWEETHEART",
    "author": "MURAKAMI",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 88,
    "bookNo": "N-89/806",
    "title": "താറാസ്‌പെഷ്യൽ",
    "author": "ബഷീർ",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 89,
    "bookNo": "N-90/808",
    "title": "തിളക്കമാർന്ന ഒരായിരം സൂര്യന്മാർ",
    "author": "ഖാലിദ് ഹൊസെയ്‌നി",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 90,
    "bookNo": "N-91/809",
    "title": "നാല്പതു പ്രണയ നിയമങ്ങൾ",
    "author": "എലിഫ് ഷഫാക്ക്",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 91,
    "bookNo": "N-92/817",
    "title": "പട്ടം പറത്തുന്നവർ ",
    "author": "ഖാലിദ് ഹൊസെയ്‌നി",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 92,
    "bookNo": "N-93/829",
    "title": "മിണ്ടാപ്പെണ്ണ്",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 93,
    "bookNo": "N-94/856",
    "title": "എല്ലാ വിധ പ്രണയവും",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 94,
    "bookNo": "N-95/846",
    "title": "ശരീര ശാസ്ത്രം",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 95,
    "bookNo": "N-96/826",
    "title": "പറുദീസാ ",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 96,
    "bookNo": "N-97/822",
    "title": "ആലം നൂർ ",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 97,
    "bookNo": "N-98/839",
    "title": "ശൂദ്രൻ ",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 98,
    "bookNo": "N-99/841",
    "title": "മാധവി കുട്ടിയുടെ പ്രണയ നോവലുകൾ ",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 99,
    "bookNo": "N-100/830",
    "title": "അവർ നിങ്ങളെയും പിടികൂടി",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 100,
    "bookNo": "N-101/824",
    "title": "ഒരു പബ്ലിക് പ്രോസിക്യൂട്ടറുടെ ഡയറിക്കുറിപ്പുകൾ",
    "author": "",
    "category": "നോവൽ(N)"
  },
  {
    "serialNo": 101,
    "bookNo": "ABE-1/567",
    "title": "THE LIFE OF LEE",
    "author": "LEE EVANS ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 102,
    "bookNo": "ABE-2/568",
    "title": "ELENA VANISHING ",
    "author": "ELENA AND CLARE ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 103,
    "bookNo": "ABE-3/396",
    "title": "TURNING POINTS",
    "author": "A.P.J ABDUL KALAM",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 104,
    "bookNo": "ABE-4/570",
    "title": "WINGS OF FIRE ",
    "author": "A.P.J ABDUL KALAM",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 105,
    "bookNo": "ABE-5/589",
    "title": "WINGS OF  FIRE",
    "author": "A.P.J ABDUL KALAM",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 106,
    "bookNo": "ABE-6/577",
    "title": "EMMANUAL MACRON REVOLUTION ",
    "author": "EMMANUEL",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 107,
    "bookNo": "ABE-7/573",
    "title": "THE STORY OF MY LIFE ",
    "author": "HELEN KELLER",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 108,
    "bookNo": "ABE-8/574",
    "title": "THE ROOM WHERE IT HAPPEND ",
    "author": "JOHN BOLTON",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 109,
    "bookNo": "ABE-9/575",
    "title": "LIVING HISTORY",
    "author": "HILLARY RODHAM CLIONTON",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 110,
    "bookNo": "ABE-10/572",
    "title": " I CAME UPON A LIGHTHOUSE ",
    "author": " SHANTANU NAIDU",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 111,
    "bookNo": "ABE-11/588",
    "title": "MEMOIRS OF A MAVERIK ",
    "author": "MANI SHANKAR AIYAR",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 112,
    "bookNo": "ABE-12/578",
    "title": "I AM MALALA",
    "author": " MALALA YOUSUF SAI",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 113,
    "bookNo": "ABE-13/579",
    "title": "AN IMPROBABLE LIFE",
    "author": "TREVOR McDONALD",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 114,
    "bookNo": "ABE-14/580",
    "title": "MY STORY",
    "author": "STEVEN GERRARD",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 115,
    "bookNo": "ABE-15/548",
    "title": "THE DIARY OF A YOUNG GIRL",
    "author": "ANNE FRANK ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 116,
    "bookNo": "ABE-16/515",
    "title": "V.P. MENON - THE UNSUNG ARCHITECT OF \nMODERN INDIA",
    "author": "NARAYANI BASU",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 117,
    "bookNo": "ABE-17/583",
    "title": "SWAMI VIVEKANANDA THE LIVING VEDANTA ",
    "author": "CHATUR VEDI BADRINATH",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 118,
    "bookNo": "ABE- 18/590",
    "title": "THE STORY OF MY EXPERIMENTS WITH TRUTH",
    "author": "M.K GANDHI",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 119,
    "bookNo": "ABE-19/585",
    "title": "I TOO HAD A DREAM",
    "author": "VERGHESE KURIEN",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 120,
    "bookNo": "ABE-20/586",
    "title": "A SHOT AT HISTORY",
    "author": "ABHINAV BINDRA",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 121,
    "bookNo": "ABM-21/697",
    "title": " ഷെയ്ഖ്   സായിദ് ",
    "author": "JALEEL RAMANTHALI",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 122,
    "bookNo": "ABM-22/343",
    "title": "പന്തു കളിക്കാരൻ   ",
    "author": "ജി.ആർ.ഇന്ദുഗോപൻ ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 123,
    "bookNo": "ABM-23/345",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 124,
    "bookNo": "ABM-24/346",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 125,
    "bookNo": "ABM-25/344",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 126,
    "bookNo": "ABM-26/600",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 127,
    "bookNo": "ABM- 27/ 339",
    "title": "ഷർമൺ ജാക്സൺ ",
    "author": "എൻ മുഹമ്മദ്‌ ഖലീൽ ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 128,
    "bookNo": "ABM- 28/305",
    "title": "എനിക്ക് ഹിന്ദുവാകാൻ കഴിഞ്ഞില്ല",
    "author": "",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 129,
    "bookNo": "ABM- 29/ 337",
    "title": "തസ്കരൻ മണിയൻ പിള്ളയുടെ ആത്മകഥ ",
    "author": "ജി ആർ ഇന്ദുഗോപൻ ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 130,
    "bookNo": "ABM- 30/ 338",
    "title": "ബോളീവിയൻ ഡയറി ",
    "author": "ഏണസ്റ്റോ ചെഗുവേര / ബിമൽ കുമാർ രാമങ്കരി ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 131,
    "bookNo": "ABM-31/ 336",
    "title": "തോൽക്കില്ല ഞാൻ ",
    "author": "ടിക്കാ റാം മീണ IAS ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 132,
    "bookNo": "ABM- 32/334",
    "title": "ന്യൂസ്‌ റൂം :ഒരു മാധ്യമ പ്രവർത്തകന്റെ \nഅനുഭവകുറിപ്പുകൾ ",
    "author": "ബി ആർ പി ഭാസ്‌കർ ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 133,
    "bookNo": "ABM- 33/ 333",
    "title": "വിരലറ്റം ഒരു IAS കാരന്റെ ജീവിതം ",
    "author": "മുഹമ്മദലി ശിഹാബ് ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 134,
    "bookNo": "ABM- 34/ 329",
    "title": "കണ്ണീരും കിനാവും ",
    "author": "വി ടി ഭട്ടത്തിരിപ്പാട് ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 135,
    "bookNo": "ABM- 35/ 332",
    "title": "എന്നിലൂടെ : കുഞ്ഞുണ്ണി മാഷിന്റെ ആത്മകഥ ",
    "author": "കുഞ്ഞുണ്ണി ",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 136,
    "bookNo": "ABM-36/715",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 137,
    "bookNo": "ABM-37/716",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 138,
    "bookNo": "ABM-38/717",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 139,
    "bookNo": "ABM-39/718",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 140,
    "bookNo": "ABM-40/719",
    "title": "അഗ്നിച്ചിറകുകൾ",
    "author": "എ പി ജെ അബ്ദുൽ കലാം",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 141,
    "bookNo": "ABE-41/720",
    "title": "WINGS OF FIRE",
    "author": "A PJ ABDUL KALAM",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 142,
    "bookNo": "ABE42/769",
    "title": "THE DIARY OF A YOUNG GIRL",
    "author": "ANNE FRANK",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 143,
    "bookNo": "ABE-43/787",
    "title": "WINGS OF FIRE",
    "author": "A.P.J ABDUL KALAM",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 144,
    "bookNo": "ABM-44/788",
    "title": "വിരലറ്റം ",
    "author": "മുഹമ്മദ് അലി ശിഹാബ്,IAS",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 145,
    "bookNo": "ABE-45/813",
    "title": "WINGS OF FIRE",
    "author": "A PJ ABDUL KALAM",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 146,
    "bookNo": "ABM-46/814",
    "title": "മാപ്പിള ഖലാസി കഥ പറയുന്നു",
    "author": "സി.എം.മുസ്തഫ ഹാജി ചേലേമ്പ്ര",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 147,
    "bookNo": "ABM-47/835",
    "title": "ജീവിതം ഇതുവരെ സയ്യിദ് ഇബ്രാഹീം തങ്ങൾ",
    "author": "",
    "category": "AUTOBIOGRAPHY"
  },
  {
    "serialNo": 148,
    "bookNo": "BI 1/591",
    "title": "ELON MUSK",
    "author": "ASHLEE VANCE ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 149,
    "bookNo": "BI 2/592",
    "title": "LENIN A BIOGRAPHY",
    "author": "ROBERT SERVICE ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 150,
    "bookNo": "BI 3/593",
    "title": "WHY I ASSASINATED GANDHI ",
    "author": "NATHURAM GODSE",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 151,
    "bookNo": "BI 4/594",
    "title": "A JUDGE IN MADRAS ",
    "author": "CAROLINE KEEN",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 152,
    "bookNo": "BI 5/595",
    "title": "A JUDGE IN MADRAS",
    "author": "CAROLINE KEEN",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 153,
    "bookNo": "BI 6/598",
    "title": "SLOGANS OF THE SAGE-SAYYID MOHAMMED ALI SHIHAB",
    "author": "MUJEEB JAIHOON",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 154,
    "bookNo": "BI 7/587",
    "title": "THE TIGER OF DRASS",
    "author": "CAPT.ANUJ NAYYAR",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 155,
    "bookNo": "BI 8/170",
    "title": "THE SOUL OF THE DESERT",
    "author": "UMER.O.THASNEEM",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 156,
    "bookNo": "BI 9/7",
    "title": "നടന്നെത്തിയ ദൂരം ",
    "author": "എം.ടി ഷിഹാബുദ്ദിൻ സഖാഫി ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 157,
    "bookNo": "BI 10/69",
    "title": "ഇബ്റാഹിം ഇബ്നു അദ്ഹം-ചരിത്യകഥ",
    "author": "ഇസ്സുദീൻ പൂകോട്ടുപോല",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 158,
    "bookNo": "BI 11/70",
    "title": "ഇടയൻ- ലുഖ്മാനുൽ ഹകീം (റ) ചരിത്രാ ഖ്യായിക",
    "author": "പുല്ലമ്പാറ ശംസുദീൻ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 159,
    "bookNo": "BI 12/71",
    "title": "നൈലിൻ്റെ പുത്യൻ",
    "author": "പുല്ലമ്പാറ ശംസുദ്ദീൻ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 160,
    "bookNo": "BI 13/72",
    "title": "നന്മ വീട്",
    "author": "സ്വാനിഖ് അൻവരി",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 161,
    "bookNo": "BI 14/36",
    "title": "താജുൽ ഉലമ ഉള്ളാൽ സയ്യിദ് അബ്ദുറഹ്മാൻ\n അൽ ബുഖാരി",
    "author": "മാളിയേക്കൽ സുലൈമാൻ സഖാഫി ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 162,
    "bookNo": "BI 15/348",
    "title": "ഞാൻ അബ്ദുൽ കലാം  ",
    "author": "വി. രാധാകൃഷ്ണൻ ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 163,
    "bookNo": "BI 16/350",
    "title": "എന്റെ സത്യാന്വേഷണപരീക്ഷണങ്ങൾ",
    "author": "ഗാന്ധിജി/ ഡോ.ജോർജ് ഇരുമ്പയം",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 164,
    "bookNo": "BI 17/351",
    "title": "എന്റെ സത്യാന്വേഷണപരീക്ഷണങ്ങൾ",
    "author": "ഗാന്ധിജി/ ഡോ.ജോർജ് ഇരുമ്പയം",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 165,
    "bookNo": "BI 18/349",
    "title": "എന്റെ സത്യാന്വേഷണപരീക്ഷണങ്ങൾ",
    "author": "ഗാന്ധിജി/ ഡോ ജോർജ് ഇരുമ്പഴം",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 166,
    "bookNo": "BI 19/667",
    "title": "എന്റെ സത്യാന്വേഷണപരീക്ഷണങ്ങൾ",
    "author": "ഗാന്ധിജി/ ഡോ ജോർജ് ഇരുമ്പഴം",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 167,
    "bookNo": "BI 20/347",
    "title": "അജയ്യമായ ആത്മചൈതന്യം ",
    "author": "APJ abdul kalam",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 168,
    "bookNo": "BI 21/342",
    "title": "ദലിതൻ ",
    "author": "കെ.കെ.കൊച്ച്",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 169,
    "bookNo": "BI 22/327",
    "title": "സ്രാവുകൾക്കൊപ്പം നീന്തുമ്പോൾ ",
    "author": "ജേക്കബ് തോമസ് ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 170,
    "bookNo": "BI 23/29",
    "title": "ഇമാം ഗസാലി ",
    "author": "വി. എ. മജീദ് ഫൈസി ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 171,
    "bookNo": "BI 24/32",
    "title": "ഇമാം ഗസാലി ",
    "author": "AK MAJEED",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 172,
    "bookNo": "BI 25/33",
    "title": "ഇമാം റാസി  (റ)",
    "author": "ഡോ.മുഹമ്മദ് ഫാറൂഖ് ബുഖാരി",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 173,
    "bookNo": "BI 26/34",
    "title": "അജ്മീർലെ സുൽത്താൻ",
    "author": " ഡോ. ഹുസൈൻ രണ്ടത്താണി",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 174,
    "bookNo": "BI 27/35",
    "title": "നൂറുൽ  ഉലമ എം എ അബ്ദുൽ ഖാദർ മുസ്ലിയാർ",
    "author": "മാനേജിംഗ് എഡിറ്റർ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 175,
    "bookNo": "BI28/27",
    "title": "ഗുരു വഴികൾ",
    "author": "ഓ എം തരുവണ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 176,
    "bookNo": "BI 29/28",
    "title": "നിസാമുദ്ദിൻ ഓലിയ -നിലാ വെളിച്ചം ",
    "author": "ജമാൽ മുഹമ്മദ്‌ ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 177,
    "bookNo": "BI 30/30",
    "title": "നിസാമുദ്ദീൻ ഔലിയ - നിലാവെളിച്ചം",
    "author": "ജമാൽ മുഹമ്മദ്‌ ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 178,
    "bookNo": "BI 31/104",
    "title": "ശൈഖ് അഹ്മദ് സർഹിന്ദി",
    "author": "ഹുസൈൻ രണ്ടത്താണി",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 179,
    "bookNo": "BI 32/14",
    "title": "ജ്വലിക്കുന്ന വിശ്വാസം",
    "author": "നൗഫൽ തൊട്ടിപ്പാലം",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 180,
    "bookNo": "BI-33/73",
    "title": "അടിമ ജീവിതം",
    "author": "പുല്ലമ്പാറ ശംസുദ്ദീൻ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 181,
    "bookNo": "BI-34/328",
    "title": "ഇലോൺ മസ്ക് -",
    "author": " പി.പി.ആൽബി",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 182,
    "bookNo": "BI-35/352",
    "title": "ഗാന്ധി ഒരു അർത്ഥ നഗ്നവായന",
    "author": "എസ് ഗോപാലകൃഷ്ണൻ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 183,
    "bookNo": "BI-36/356",
    "title": "സുഭാഷ് ചന്ദ്രബോസിൻ്റെ തിരോധാനം - ",
    "author": "പി.ആറ്.രാഖേഷ്",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 184,
    "bookNo": "BI-37/331",
    "title": "ഹാജി ഫ്രം ഇന്ത്യ - ",
    "author": "അമ്മാർ കീയൂപറമ്പു",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 185,
    "bookNo": "BI-38/335",
    "title": "ബോധ്യങ്ങൾ നടത്തിച്ച ജീവിതം - ",
    "author": " സദാശിവൻ ഇരിങ്ങൽ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 186,
    "bookNo": "BI-39/330",
    "title": "നക്ഷത്രങ്ങളുടെ സ്നേഹഭാജനം ",
    "author": "- എം. കേ. സാനു",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 187,
    "bookNo": "BI-40/353",
    "title": "പ്രാർത്ഥന,എം കേ ഗാന്ധി - ",
    "author": "സിസിലി",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 188,
    "bookNo": "BI-41/340",
    "title": "ജീവിതകഥ, ആന് ഫ്രാങ്ക് - ",
    "author": "സത്യൻ കല്ലുരുട്ടി",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 189,
    "bookNo": "BI-42/476",
    "title": "നടന്നെത്തിയ ദൂരം ",
    "author": "എം.ടി ഷിഹാബുദ്ദിൻ സഖാഫി ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 190,
    "bookNo": "BI-43/253",
    "title": "കൈയൊപ്പിട്ട വഴികൾ",
    "author": "ദിവ്യ എസ്.അയ്യർ",
    "category": "BIOGRAPHY(BI)"
  },
  {
    "serialNo": 191,
    "bookNo": "C-1/402",
    "title": "സാഹിത്യ വാരഫലം ",
    "author": "എം. കൃഷ്ണൻ നായർ ",
    "category": "CRITCISM"
  },
  {
    "serialNo": 192,
    "bookNo": "Ne-1/412",
    "title": "Oliver twist ",
    "author": "Charles dickens ",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 193,
    "bookNo": "Ne-2/413",
    "title": "Retreat hell !",
    "author": "W.E.B Griffen",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 194,
    "bookNo": "Ne-3/414",
    "title": "Animal farm",
    "author": "Geroge Orwell ",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 195,
    "bookNo": "NE-4/445",
    "title": "ALL THIS TIME ",
    "author": "MIKKI DAUGHTRY AND RACHAEL \nLIPPINCOTT ",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 196,
    "bookNo": "NE-5/416",
    "title": "THE DAVINCI CODE",
    "author": "DAN BROWN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 197,
    "bookNo": "NE-6/417",
    "title": "INFERNO",
    "author": "DAN BROWN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 198,
    "bookNo": "NE-7/418",
    "title": "ORIGIN",
    "author": "DAN BROWN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 199,
    "bookNo": "NE-8/419",
    "title": "THE LOST SYMBOL",
    "author": "DAN BROWN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 200,
    "bookNo": "NE-9/420",
    "title": "THE ROOSTER BAR",
    "author": "JOHN GRISHAM",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 201,
    "bookNo": "NE-10/421",
    "title": "THE ASSOCIATE",
    "author": "JHON GRISHAM",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 202,
    "bookNo": "NE-11/422",
    "title": "THE STREET LAWYER",
    "author": "JHON GRISHAM",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 203,
    "bookNo": "NE-12/423",
    "title": "THE GOD OF SMALL THINGS",
    "author": "ARUNDHATI ROY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 204,
    "bookNo": "NE-13/424",
    "title": "AZADI FREEDOM ,FASCISM,FICTION",
    "author": "ARUNDHATI ROY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 205,
    "bookNo": "NE-14/425",
    "title": "THE BAELA MURDER CASE",
    "author": "DHAVAL KULKARNI",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 206,
    "bookNo": "NE-15/426",
    "title": "THE HYPNOTIST",
    "author": "LARS KEPLER",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 207,
    "bookNo": "NE-16/435",
    "title": "The lake  house",
    "author": "Kate morton",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 208,
    "bookNo": "NE-17/428",
    "title": "THE MOUNTAINS SING",
    "author": "NGUYEN PHAN QUEMAI",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 209,
    "bookNo": "NE-18/429",
    "title": "LEGAL FICTION",
    "author": "CHANDAN PANDEY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 210,
    "bookNo": "NE-19/430",
    "title": "THE TEETH OF THE TIGER",
    "author": "TOM CLANCY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 211,
    "bookNo": "NE-20/431",
    "title": "BURNED",
    "author": "THOMAS ENGER",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 212,
    "bookNo": "NE-21/464",
    "title": "WHERE DO YOU GO IN THE DARK, MY LOVE?",
    "author": "ISHA SINGH",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 213,
    "bookNo": "NE-22/433",
    "title": "SCARE CROW",
    "author": "MATTHEW REILLY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 214,
    "bookNo": "NE-23/434",
    "title": "THE PRESIDANT IS MISSING",
    "author": "BILLCLINTON JAMES PATTERSON",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 215,
    "bookNo": "NE 24/471",
    "title": "DEAD AT FIRST SIGHT",
    "author": "PETER JAMES",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 216,
    "bookNo": "NE 25/466",
    "title": "THE TARGET",
    "author": "DAVID BALDACCI",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 217,
    "bookNo": "NE 26/468",
    "title": "SRILAAJI",
    "author": "SOBHAA DE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 218,
    "bookNo": "NE 27/469",
    "title": "SRILAAJI",
    "author": "SOBHAA DE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 219,
    "bookNo": "NE-28/439",
    "title": "The kite runner",
    "author": "Khaled hosseini",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 220,
    "bookNo": "NE-29/440",
    "title": "AThousand speendid suns",
    "author": "Khaled hosseini ",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 221,
    "bookNo": "NE-30/441",
    "title": "WINTERS TALE",
    "author": "MARK HELPRIN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 222,
    "bookNo": "NE-31/442",
    "title": "DOPEHRI",
    "author": "Pankaj kapur",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 223,
    "bookNo": "NE-32/443",
    "title": "DOPEHRI ",
    "author": "Pankaj kapur ",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 224,
    "bookNo": "NE-33/751",
    "title": "ANIMAL FARM",
    "author": "GEORGE ORWELL",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 225,
    "bookNo": "NE-34",
    "title": "",
    "author": "",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 226,
    "bookNo": "NE-35/446",
    "title": "THE MAN I THINK I KNOW ",
    "author": "MIKE GAYLE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 227,
    "bookNo": "NE-36/447",
    "title": "KINTSUGI",
    "author": "ANUKRTI UPADHYAY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 228,
    "bookNo": "NE-37/448",
    "title": " THE ALCHEMY OF DESIRE",
    "author": "TARUN J TEJPAL",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 229,
    "bookNo": "NE-38/449",
    "title": "RUN AWAY",
    "author": "HARLAN COBEN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 230,
    "bookNo": "NE 39/475",
    "title": "NORMAL PEOPLE",
    "author": "SALLY ROONEY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 231,
    "bookNo": "NE-40/451",
    "title": "FUTURE TENSE",
    "author": "NITASHA KAUL",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 232,
    "bookNo": "NE-41/452",
    "title": "THE RETURN",
    "author": "VICTORIA HILSOP",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 233,
    "bookNo": "NE-42/453",
    "title": "ACCIDENTAL MAGIC ",
    "author": "KESHAVA GUHA",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 234,
    "bookNo": "NE-43/454",
    "title": "INNOCENCE ",
    "author": "DEAN KOONTZ",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 235,
    "bookNo": "NE-44/455",
    "title": "BAAZ",
    "author": "ANUJA CHAUHAN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 236,
    "bookNo": "NE-45/456",
    "title": "MIDNIGHT'S CHILDREN ",
    "author": "SALMAN RUSHDIE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 237,
    "bookNo": "NE-46/457",
    "title": "KANE AND ABEL",
    "author": "JEFFREY ARCHER",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 238,
    "bookNo": "NE-47/458",
    "title": "HEADS YOU WIN",
    "author": "JEFFREY ARCHER",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 239,
    "bookNo": "NE-48/459",
    "title": "HEADS YOU WIN",
    "author": "JEFFREY ARCHER",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 240,
    "bookNo": "NE-49/460",
    "title": "THE FOURTH ESTATE",
    "author": "JEFFREY ARCHER",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 241,
    "bookNo": "NE-50/461",
    "title": "KING OF KINGS",
    "author": "WILBUR SMITH",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 242,
    "bookNo": "NE-51/462",
    "title": "VAGABOND ",
    "author": "GERALD SEYMOUR",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 243,
    "bookNo": "NE-52/463",
    "title": "LES MISERABLES",
    "author": "VICTOR HUGO",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 244,
    "bookNo": "NE-53/450",
    "title": "THE NARROW ROAD TO THE DEEP NORTH",
    "author": "RICHARD FLANAGAN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 245,
    "bookNo": "NE 54/467",
    "title": "SAVING FAITH",
    "author": "DAVID BALDACCI",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 246,
    "bookNo": "NE 55 \\478",
    "title": "THE WOODLANDERS",
    "author": "THOMAS HARDY",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 247,
    "bookNo": "NE 56\\479",
    "title": "SHUGGIE BAIN",
    "author": "DOUGLAS STUART",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 248,
    "bookNo": "NE 57/473",
    "title": "E IS FOR EVIDENCE",
    "author": "SUE  GRAFTONE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 249,
    "bookNo": "NE 58\\477",
    "title": "WHITE LIES,BLACK DARE",
    "author": "JOANNA NADIN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 250,
    "bookNo": "NE 59\\480",
    "title": "TOMB OF SAND",
    "author": "GEETANJALI SHREE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 251,
    "bookNo": "NE 60/436",
    "title": "2 STATES ",
    "author": "CHETAN BHAGAT",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 252,
    "bookNo": "NE61/474",
    "title": "THE END OF MEN ",
    "author": "CHRISTINA BAIRD",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 253,
    "bookNo": "NE 62/432",
    "title": "WHAT HAPPENED THAT NIGHT ",
    "author": "SHILA O FLANGON",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 254,
    "bookNo": "NE 63/ 465",
    "title": "THE SUMMER WITHOUT YOU",
    "author": "KAREN SWAN",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 255,
    "bookNo": "NE 64 /481",
    "title": "NEVER NEVER",
    "author": "COLLEEN HOOVER,TARRYN FISHER",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 256,
    "bookNo": "NE 65/395",
    "title": "THE STOLEN MAGIC",
    "author": "DIANE CHAMBERLANE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 257,
    "bookNo": "NE 66/175",
    "title": "ALICES ADVANTURE IN WONDERLAND&....",
    "author": "......",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 258,
    "bookNo": "NE 67/181",
    "title": " RECKLESS",
    "author": "SHANON DRAKE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 259,
    "bookNo": "NE-68/438",
    "title": "And the mountains echoed",
    "author": "Khaled hosseini",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 260,
    "bookNo": "NE-69/483",
    "title": "AThousand speendid suns",
    "author": "Khaled hosseini ",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 261,
    "bookNo": "NE-70/755",
    "title": "THE ALCHEMIST",
    "author": "PAULO COELHO",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 262,
    "bookNo": "NE-71/756",
    "title": "THE ALCHEMIST",
    "author": "PAULO COELHO",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 263,
    "bookNo": "NE-72/759",
    "title": "THE CANTERVILLE GHOST",
    "author": "OSCAR WILDE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 264,
    "bookNo": "NE73/760",
    "title": "THE CANTERVILLE GHOST",
    "author": "OSCAR WILDE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 265,
    "bookNo": "NE-74/778",
    "title": "THE LOVELY BONES",
    "author": "ALICE SEBOLD",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 266,
    "bookNo": "NE-75/785",
    "title": "THE ALCHEMIST",
    "author": "PAULO COELHO",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 267,
    "bookNo": "NE-76/786",
    "title": "THE CANTERVILLE GHOST",
    "author": "OSCAR WILDE",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 268,
    "bookNo": "NE-77/799",
    "title": "The Stationery Shop of Thehran",
    "author": "Marjan kamali",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 269,
    "bookNo": "NE-78/801",
    "title": "Swami And Friends",
    "author": "R.K. Naryanan",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 270,
    "bookNo": "NE-79/804",
    "title": "ANIMAL FARM",
    "author": "GEORGE ORWELL",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 271,
    "bookNo": "NE-80/810",
    "title": " the vegitarian",
    "author": "han kang",
    "category": "English Novel(NE)"
  },
  {
    "serialNo": 272,
    "bookNo": "G-1/535",
    "title": "NO NATION FOR WOMEN",
    "author": "PRIYANKA DUBEY",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 273,
    "bookNo": "G-2/536",
    "title": "INQUILAB A DECADE OF PROTEST",
    "author": "SWARA BHASKER",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 274,
    "bookNo": "G-3/537",
    "title": "OUR  FREEDOMS",
    "author": "NILANJANA S ROY",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 275,
    "bookNo": "G-4/538",
    "title": "NIGHT MARCH A JOURNEY INTO INDIA'S NAXAL HEART LANDS",
    "author": "ALPA SHAH",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 276,
    "bookNo": "G-5/539",
    "title": "BATTLING INJUSTICE-16 WOMEN NOBLE PEACE LAUREATES",
    "author": "SUPRIYA VANI",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 277,
    "bookNo": "G-6/540",
    "title": "SECOND THOUGHTS ON BOOKS,AUTHORS AND THE WRITERLY LIFE",
    "author": "NAVTEJ SARMA",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 278,
    "bookNo": "G-7/541",
    "title": "2019 HOW MODI WON INDIA",
    "author": "RAJDEEP SARDESAI",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 279,
    "bookNo": "G-8/542",
    "title": "THE HANGING OF AFZAL GURU",
    "author": "ARUNDHATHI ROY",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 280,
    "bookNo": "G-9/543",
    "title": "THE NAME SAKE",
    "author": "JHUMPA LAHIRI",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 281,
    "bookNo": "G-10/544",
    "title": "JUST PLAY",
    "author": "VINITA SIDHARTHA",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 282,
    "bookNo": "G-11/545",
    "title": "PAX INDICA",
    "author": "SHASHI THAROOR",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 283,
    "bookNo": "G-12/546",
    "title": "DEEP WORK",
    "author": "CAL NEW PORT",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 284,
    "bookNo": "G-13/547",
    "title": "HIT REFRESH",
    "author": "SATYA NABELLA",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 285,
    "bookNo": "G-14/549",
    "title": "ROCKETING THROUGH THE SKIES",
    "author": "G MADHAVAN NAIR",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 286,
    "bookNo": "G-15/601",
    "title": "SHAROENING THE ARSENAL",
    "author": "Gurmeet Ranwal",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 287,
    "bookNo": "G-16/602",
    "title": "THE INDIA WAY",
    "author": "S Jaishankar",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 288,
    "bookNo": "G-17/603",
    "title": "THE SWACHH BHARATH REVOLUTION ",
    "author": "Parameswaran iyar",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 289,
    "bookNo": "G-18/604",
    "title": "THE GEAT GAME IN AFGHANISTAN",
    "author": "Rallol Bhattacharjee",
    "category": "GENERAL ENGLISH(GE)"
  },
  {
    "serialNo": 290,
    "bookNo": "H-1/311",
    "title": "നഷ്ടപ്പെട്ട ചരിത്രം The lost history",
    "author": "മൈക്കിൾ ഹാമിൽട്ടൻ മോർഗൻ /വി ടി സന്തോഷ്‌കുമാർ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 291,
    "bookNo": "H-2/312",
    "title": "അറിയപ്പെടാത്ത ഇന്ത്യ ",
    "author": "ഡോ ഹുസൈൻ രണ്ടത്താണി ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 292,
    "bookNo": "H-3/314",
    "title": "കേരള ചരിത്രം ",
    "author": "‏പ്രൊ. ടി കെ ഗംഗാദരൻ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 293,
    "bookNo": "H-4/315",
    "title": "മോസാദ് : ഇസ്രായേലി രഹസ്യ എജൻസിയുടെ \nസുപ്രദാന ദൗത്യങ്ങൾ",
    "author": "മൈക്കൽ ബാർ സൊഹാർ നിസിം മിഷാൽ /pjj ആന്റണി ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 294,
    "bookNo": "H-5/316",
    "title": "കേരളം : ഇരുളടഞ്ഞ ഇന്നലെകൾ ",
    "author": "സുരേന്ദ്രൻ ചീക്കിലോട് ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 295,
    "bookNo": "H-6/317",
    "title": "ജനാധിപത്യവാദികളും വിമതരും ",
    "author": "രാമചന്ദ്രഗുപ്ത / കെ സി വിൽസൺ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 296,
    "bookNo": "H-7/319",
    "title": "സ്വാതന്ത്ര്യം അർദ്ധരാത്രിയിൽ ",
    "author": "ലാരികൊളിൻസ് ഡോമിനിക് ലാപിയർ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 297,
    "bookNo": "H-8/320",
    "title": "ആധുനിക ഇന്ത്യ ",
    "author": "ബിപൻ ചന്ദ്ര / സെൻ കുര്യൻ ജോസ് ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 298,
    "bookNo": "H-9/321",
    "title": "ഹോമോദിയൂസ് മനുഷ്യഭാവിയുടെ \nഒരു ഹൃസ്വചരിത്രം",
    "author": "യുവാൽ നോവാ ഹാരാരി / പ്രസന്ന കെ വർമ്മ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 299,
    "bookNo": "H-10/385",
    "title": "ഹോമോദിയൂസ് - മനുഷ്യഭാവിയുടെ\n ഒരു ഹരസ്വചിത്രം ",
    "author": "യുവൽ നോവാ ഹാരാരി ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 300,
    "bookNo": "H-11/322",
    "title": "ഭരണഘടന: ഇന്ത്യൻ റിപ്പബ്ലിക്കിന്റെ \nഅതിജീവന ചരിത്രം  ",
    "author": "അഡ്വ : വി ആർ ഹരിദാസ് ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 301,
    "bookNo": "H-12/323",
    "title": "ദന്തസിംഹാസനം തിരുവിതാംകൂർ രാജവംശത്തിന്റെ\n നാൾവഴികൾ",
    "author": "മനു എസ് പിള്ള / പ്രസന്ന കെ വർമ്മ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 302,
    "bookNo": "H-13/161",
    "title": "മലബാർ കലാപം പ്രബുദ്ധത്തിനും\n രാജവാഴ്ചയ്ക്കും എതിരെ എതിരെ \n",
    "author": "എ കെ എൻ പണിക്കർ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 303,
    "bookNo": "H-14/159",
    "title": "1921 പോരാളികൾ വരച്ച ദേശ ഭൂപടങ്ങൾ",
    "author": "പി സുരേന്ദ്രൻ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 304,
    "bookNo": "H-15/406",
    "title": "1921-2021 കേരള മുസ്ലിങ്ങൾ നൂറ്റാണ്ടിന്റെ ചരിത്രം ",
    "author": "എം. ജി. എസ് നാരായണൻ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 305,
    "bookNo": "H-16/68",
    "title": "ബദ്ർ-ചരിത്രം പുസ്തകം",
    "author": "യുസുഫ്ഫൈസി കാത്തിരപ്പുഴ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 306,
    "bookNo": "H-17/252",
    "title": "മുസ്ലിം ഇന്ത്യയുടെ ചരിത്ര വായന",
    "author": "ഡോ ഹുസൈൻ രണ്ടത്താണി",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 307,
    "bookNo": "H-18/581",
    "title": "ഒക്ടോബർ 7 ഇസ്രായേൽ ഹമാസ് സംഘർഷത്തിന്റെ \nഅകവും പുറവും",
    "author": "എം എൻ സുഹൈബ്",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 308,
    "bookNo": "H-19/584",
    "title": "മുകുളന്മാരും സൂഫികളും ",
    "author": "മുഹമ്മദ് ഷമീർ കൈപ്പങ്ങര",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 309,
    "bookNo": "H-20/576",
    "title": "ഒരു ജന്മം ഒരായിരം മരണം",
    "author": "കബനി",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 310,
    "bookNo": "H- 21/318",
    "title": "തകർന്ന റിപ്പബ്ലിക് ",
    "author": "അരുന്ധതി റോയ് ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 311,
    "bookNo": "H-22/325",
    "title": "ദേശിയ വാദവും വിമതസ്വരങ്ങളും ",
    "author": "റൊമില ഥാപ്പർ / ബിജീഷ് ബാലകൃഷ്ണൻ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 312,
    "bookNo": "H-23/324",
    "title": "അടിമ കേരളത്തിന്റെ അദൃശ്യ ചരിത്രം ",
    "author": "വിനിൽ പോൾ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 313,
    "bookNo": "H-24/326",
    "title": "അനാർക്കി,  ഈസ്റ്റ് ഇന്ത്യ കമ്പനി നടത്തിയ \nആക്രമം,  സാമ്രാജ്യത്വ കൊള്ളയടി  ",
    "author": "വില്യം ടാർ റിമ്പിൾ / സുരേഷ് എം പി ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 314,
    "bookNo": "H-25/98",
    "title": "ഇന്ത്യൻ സ്വാതന്ത്ര്യ സമരത്തിൽ മുസ്ലിങ്ങളുടെ പങ്ക്",
    "author": "എ ആർ കൊടിയത്തൂർ ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 315,
    "bookNo": "H-26/571",
    "title": "ഹൈദർ അലിക്കും ടിപ്പുസുൽത്താനും കീഴിൽ",
    "author": "ഇർഫാൻ ഹബീബ്",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 316,
    "bookNo": "H-27/309",
    "title": "സാപ്പിയെൻസ് മനുഷ്യരാശിയുടെ ഒരു ഹൃസ്സ ചരിത്രം",
    "author": "യുവാൽ നോവ ഹരാരി ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 317,
    "bookNo": "H-28/560",
    "title": "മലബാർ മക്കൾ",
    "author": "",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 318,
    "bookNo": "H-29/752",
    "title": "പരാന്നഭോജികൾ",
    "author": "വിനിൻ പെരീര / ജെറമി സീബിറൂക്ക് ",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 319,
    "bookNo": "H-30/797",
    "title": "ഷാജഹാൻ നിർമ്മിതികളുടെ രാജകുമാരന്റെ",
    "author": "പ്രിയ ദിനേശ്",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 320,
    "bookNo": "H-31/855",
    "title": "കനൽ ജീവിതം ",
    "author": "",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 321,
    "bookNo": "H-32/849",
    "title": "കോഴിക്കോടിൻറെ ചരിത്രം ",
    "author": "",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 322,
    "bookNo": "H-33/838",
    "title": "ജഹാംഗീർ",
    "author": "",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 323,
    "bookNo": "H-34/828",
    "title": "ഹുമയൂൺ",
    "author": "",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 324,
    "bookNo": "H-35/823",
    "title": "ബാബർ",
    "author": "",
    "category": "ചരിത്രം"
  },
  {
    "serialNo": 325,
    "bookNo": "HE 1/605",
    "title": "SAPIENS",
    "author": "YUVEN NOAH HARARI",
    "category": "History (English)"
  },
  {
    "serialNo": 326,
    "bookNo": "HE 2/606",
    "title": "HOMO DEUS",
    "author": "YUVAL NOAH HARARI",
    "category": "History (English)"
  },
  {
    "serialNo": 327,
    "bookNo": "HE 3/607",
    "title": "ON THIS DAY IN HISTORY",
    "author": "DANCE SNOW",
    "category": "History (English)"
  },
  {
    "serialNo": 328,
    "bookNo": "HE 4/608",
    "title": "WHY I AM A HINDU",
    "author": "SHASHI THAROOR",
    "category": "History (English)"
  },
  {
    "serialNo": 329,
    "bookNo": "HE 5/609",
    "title": "THE RULERS GAZE",
    "author": "ARVIND SHARMA ",
    "category": "History (English)"
  },
  {
    "serialNo": 330,
    "bookNo": "HE 6/610",
    "title": "SUPERIOR",
    "author": "ANGELA SAINI",
    "category": "History (English)"
  },
  {
    "serialNo": 331,
    "bookNo": "HE 7/611",
    "title": "THE DISCOVERY OF INDIA",
    "author": "JAWARHARLAL NEHRU",
    "category": "History (English)"
  },
  {
    "serialNo": 332,
    "bookNo": "HE 8/612",
    "title": "DARA SHUKOH",
    "author": "AVIK CHANDA",
    "category": "History (English)"
  },
  {
    "serialNo": 333,
    "bookNo": "HE 9/613",
    "title": "KERALA HISTORY AND ITS MAKERS",
    "author": "A SREDHARA MENON",
    "category": "History (English)"
  },
  {
    "serialNo": 334,
    "bookNo": "HE 10/614",
    "title": " DAYS IN THE LIFE OF A SUFI",
    "author": "RAZIUDDIN AQUIL",
    "category": "History (English)"
  },
  {
    "serialNo": 335,
    "bookNo": "HE 11/615",
    "title": "THE POISONED HEART",
    "author": "NANDINI  SENGUPTA",
    "category": "History (English)"
  },
  {
    "serialNo": 336,
    "bookNo": "HE 12/616",
    "title": "THE EDEN LEGACY",
    "author": "WILL ADAMS",
    "category": "History (English)"
  },
  {
    "serialNo": 337,
    "bookNo": "HE 13/674",
    "title": "HISTORY OF MODERN INDIA",
    "author": "BIPAN CHANDRA",
    "category": "History (English)"
  },
  {
    "serialNo": 338,
    "bookNo": "HE-14/796",
    "title": "INDIA AFTER GANDHI",
    "author": "RAMACHANDRA GUHA",
    "category": "History (English)"
  },
  {
    "serialNo": 339,
    "bookNo": "HE-15/816",
    "title": "OVERTURE OF HOPE ",
    "author": "VINCENT",
    "category": "History (English)"
  },
  {
    "serialNo": 340,
    "bookNo": "IS-1/162",
    "title": "ഹദീസ് അർത്ഥവും വ്യാഖ്യാനവും",
    "author": "കോടമ്പുഴ ബാവ  മുസ്‌ലിയാര്‍ ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 341,
    "bookNo": "IS-2/1",
    "title": "ഇസ്‌ലാം മതം ",
    "author": "മാളിയേക്കൽ  സുലൈമാൻ സഖാഫി ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 342,
    "bookNo": "IS-3/357",
    "title": "വിദ്യാർത്ഥികൾക്ക് ഒരു വിജ്ഞാന ഡയറി",
    "author": "അബു ഫായിസ തിരുവമ്പാടി",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 343,
    "bookNo": "IS-4/390",
    "title": "നിസ്‌കാരം",
    "author": "സ്വാദിഖ് അൻവാരി",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 344,
    "bookNo": "IS-5/155",
    "title": "ഹദീസ് ചരിത്രവും ചൈതന്യയും",
    "author": "ഒരു സംഘം ലേഖകർ ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 345,
    "bookNo": "IS-6/25",
    "title": "ഇസ്‌ലാമിക ജ്ഞാന ശാസ്ത്രത്തിനൊരാമുഖം",
    "author": "ഡോ മുല്യാദികർ ട്ടനെഗാര /ഹസീം മുഹമ്മദ്‌ ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 346,
    "bookNo": "IS-7/169",
    "title": "ഗുരു വഴികൾ",
    "author": "ഓ എം തരുവണ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 347,
    "bookNo": "IS-8/388",
    "title": "സ്വലാത്ത് :പഠനവും മഹത്ത്വവും",
    "author": "സയ്യിദ് അബ്ദുറഹ്മാൻ സഖാഫി \t ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 348,
    "bookNo": "IS-9/285",
    "title": "വ്യക്തി കുടുഓംബം നാസ്കികതയിലും ഇസ്ലമിലും",
    "author": "ശൈഖ് മുഹമ്മദ് കാരകുന്ന്",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 349,
    "bookNo": "IS-10/23",
    "title": "ഒരു അമുസ്ലിമിന്റ് പ്രിയപ്പെട്ട ഇസ് ലാം ",
    "author": "എ. സജീവൻ ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 350,
    "bookNo": "IS-11/156",
    "title": "ഖുർആൻ അടിസ്ഥാന തത്വങ്ങൾ ",
    "author": "മൗലാനാ അബ്ദുൽ കലാം ആസാദ്",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 351,
    "bookNo": "IS-12/31",
    "title": "കനൽ ജീവിതം  പണ്ഡിത ചരിത്രകഥകൾ",
    "author": "യൂസുഫ് ഫൈസി കാഞ്ഞിരപ്പുഴ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 352,
    "bookNo": "IS-13/700",
    "title": "ദുആകളുടെ അമാനുഷിക ഫലങ്ങൾ",
    "author": "മൗലാനാ മുഹമ്മദ് ഇല്യാസ് നദ്‌വി",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 353,
    "bookNo": "IS-14/4",
    "title": "ഇഹ്‌യാ ഉലൂമുദ്ധീൻ സംഗ്രഹം",
    "author": "ഹബീബ് ഉമർ ഹഫീള് യമൻ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 354,
    "bookNo": "IS-15/97",
    "title": "സ്നേഹ കുടുംബം",
    "author": "സയ്യിദ് ഇബ്രാഹിം ഖലീൽ അൽ ബുഖാരി",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 355,
    "bookNo": "IS-16/21",
    "title": "ഇമാം ഗസ്സാലി\n : നേർ വഴിയിലേക്ക് ആദ്യ ചുവട്",
    "author": "ഇസ്ഹാഖ് അഹ്സനി",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 356,
    "bookNo": "IS-17/172",
    "title": "ഖുർആൻ പ്രായോഗിക ജീവിതത്തിൽ",
    "author": "അബ്ദുൽ റഷീദ് സഖാഫി ഏലംകുളം",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 357,
    "bookNo": "IS-18/171",
    "title": "മുസ്ലിങ്ങളും ശരിയത്ത് നിയമങ്ങളും",
    "author": "നൂറുൽ ഉലമ എം എ അബ്ദുൽ ഖാദിർ മുസ്ലിയാർ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 358,
    "bookNo": "IS-19/10",
    "title": "ഇസ്‌ലാമിക പ്രബോധനം വഴിയും രീതിയും",
    "author": "ഇമാം അബ്ദുല്ലാഹിൽ ഹദ്ദാദ് ( റ )",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 359,
    "bookNo": "IS-20/11",
    "title": "ഒരു മലയാളി മുസ്ലിമിൻറെ നോമ്പു വിചാരങ്ങൾ ഉറുദി",
    "author": "റഫീക്ക് തിരുവള്ളൂർ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 360,
    "bookNo": "IS-21/178",
    "title": "വിശിഷ്ട പാഥേയം",
    "author": "സയ്യിദ് ഫസൽ ആറ്റക്കോയ തങ്ങൾ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 361,
    "bookNo": "IS-22/19",
    "title": "ആത്മീയോൽ ക്കർഷത്തിന്റെ വിഹായസ്സിലേക്ക്",
    "author": "കോടമ്പുഴ ബാവാ മുസ്ലിയാർ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 362,
    "bookNo": "IS-23/18",
    "title": "ചിന്തിക്കുന്നവർക്ക് ദൃഷ്ടാന്തങ്ങൾ",
    "author": "എ.ആർ. കൊടിത്തൂർ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 363,
    "bookNo": "IS-24/20",
    "title": "മടവൂരിന്റെ മണ്ണും മനസും ",
    "author": "മുസ്തഫൽ ഫാളിലി കീരീറ്റിപറമ്പ് ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 364,
    "bookNo": "IS-25/157",
    "title": "വിശുദ്ധ ഖുർആൻ ആധുനിക യുഗത്തിൽ",
    "author": "അബ്ദുൽ അസീസ് സഖാഫി വാളക്കുളം",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 365,
    "bookNo": "IS-26/3",
    "title": "ഒരു അമുസ്‌ലിമിന്റെ  പ്രിയപ്പെട്ട ഇസ്‌ലാം ",
    "author": "എ. സജീവൻ ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 366,
    "bookNo": "IS-27/470",
    "title": "ഫതാവ അസിസിയ്യാ",
    "author": "കാന്തപുരം എ പി മുഹമ്മദ് മുസ്‌ലിയാർ",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 367,
    "bookNo": "IS-28/793",
    "title": "വഴിവിളക്കുകൾ",
    "author": "യൂസഫ് ഫൈസി",
    "category": "ISLAMIC"
  },
  {
    "serialNo": 368,
    "bookNo": "L-1/681",
    "title": "GREAT WORKS OF WILLIAM SHAKESPEARE",
    "author": "SHAKESPEARE",
    "category": "LITERATURE"
  },
  {
    "serialNo": 369,
    "bookNo": "L-2/140",
    "title": "ഈ ജീവിതം കൊണ്ട് ഇത്ര മാത്രം ",
    "author": "മാധവിക്കുട്ടി",
    "category": "LITERATURE"
  },
  {
    "serialNo": 370,
    "bookNo": "L-3/401",
    "title": "നൂർ-അഫ്‌ഗാൻയുദ്ധ പശ്ചാതലത്തിൽ ",
    "author": "അക്ബർ എസ്. അഹ്‌മദ്‌ ",
    "category": "LITERATURE"
  },
  {
    "serialNo": 371,
    "bookNo": "M-1/254",
    "title": "അശ്വത്ഥാമാവ് വെറും ഒരു ആന ",
    "author": "എം ശിവ ശങ്കർ ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 372,
    "bookNo": "M-2/255",
    "title": "ഓർമപ്പാടം ",
    "author": "പി ബാലചന്ദ്രൻ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 373,
    "bookNo": "M-3/256",
    "title": "പിറന്നവർക്കും പറന്നവർക്കുമിടയിൽ ",
    "author": "ഷിംന അസീസ്ഷിംന അസീസ്",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 374,
    "bookNo": "M-4/257",
    "title": " കാൻസർ കഥ പറയുമ്പോൾ ",
    "author": "ഡോ ഈ നാരായണൻകുട്ടി വാരിയർ, എം കെ രാമദാസ് ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 375,
    "bookNo": "M-5/259",
    "title": "നനഞ്ഞു തീർത്ത മഴകൾ",
    "author": "ദീപാ നിശാന്ത് ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 376,
    "bookNo": "M-6/262",
    "title": "കുന്നോളം ഉണ്ടല്ലോ ഭൂതകാല കുളിര് ",
    "author": "ദീപാ നിശാന്ത്",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 377,
    "bookNo": "M-7/265",
    "title": "രത്‌നാടനം ",
    "author": "സലിം തൊടുകയിൽ /ജി. ജ്യോതിലാൽ ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 378,
    "bookNo": "M-8/641",
    "title": "പാരിതോഷികം",
    "author": "കൊച്ചു ഔസേപ്പ് ചിറ്റിലപ്പിള്ളി ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 379,
    "bookNo": "M-9/260",
    "title": "ഒറ്റമര പ്പെയ്ത്ത് ",
    "author": "ദീപ നിശാന്ത് ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 380,
    "bookNo": "M-10/640",
    "title": "ചിരി പുരണ്ട ജീവിതങ്ങൾ ",
    "author": "രമേശ് പിഷാരടി",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 381,
    "bookNo": "M-11/182",
    "title": "ഓർമകളിലെ ഒ.ഖാലിദ്",
    "author": "അശ്റഫ് മന്ന",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 382,
    "bookNo": "M-12/26",
    "title": "ഓർമകളിലെ ഒ.ഖാലിദ്",
    "author": "അശ്റഫ് മന്ന",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 383,
    "bookNo": "M-13/266",
    "title": "എന്റെ ജയിലനുഭവങ്ങൾ",
    "author": "സുബൈദ ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 384,
    "bookNo": "M-14/267",
    "title": "ഉമ്മ - സ്മൃതി ചിത്രങ്ങൾ",
    "author": "എം എൻ കാരശ്ശേരി",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 385,
    "bookNo": "M-15/268",
    "title": "ബ്ലാക്ക് വാറന്റ് - തീഹാർ ജയിലിലൂടെ",
    "author": "സുനിൽ ഗുപ്ത സുനേത്ര/ രാധാകൃഷ്ണൻ തൊടുപുഴ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 386,
    "bookNo": "M-16/95",
    "title": "പേര് ഫാഇസ് വയസ്സ് പത്തൊമ്പത് ദേശം കൊളപ്പുറം ",
    "author": "സാബിഖ് പബ്ലിക്കേഷൻ ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 387,
    "bookNo": "M-17/96",
    "title": "വെള്ളില സ്മരണകൾ",
    "author": "വെള്ളില മുഹമ്മദ് ഫൈസി സ്മരണകൾ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 388,
    "bookNo": "M-18/263",
    "title": "പ്രഭാതത്തിലെ പ്രതിജ്ഞ",
    "author": "റോമേയ്ൻ ഗാരി / കൃഷ്ണ ജെ. സി ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 389,
    "bookNo": "M-19/358",
    "title": "ഇവൻ എന്റെ പ്രിയ. സി. ജെ",
    "author": "റോബി തോമസ്തോമസ് ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 390,
    "bookNo": "M-20/270",
    "title": "കഥയിലൊതുങ്ങാത്ത നേരുകൾ",
    "author": "പി സുരേന്ദ്രൻ ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 391,
    "bookNo": "M-21/341",
    "title": "അവസാനത്തെ പെൺകുട്ടി ",
    "author": "നാദിയ മുറാദ് / ജന്ന ക്രാജസ്കി ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 392,
    "bookNo": "M-22/354",
    "title": "മഹാത്മാഗാന്ധിയുടെ സുവിശേഷങ്ങൾ",
    "author": "FR THOMAS ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 393,
    "bookNo": "M-23/264",
    "title": "മുറിവുകൾ",
    "author": "സൂര്യ കൃഷ്ണമൂർത്തി",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 394,
    "bookNo": "M-24/44",
    "title": "തൃക്കരിപ്പൂർ ചോര പുരണ്ട കഥകൾ പറയുമ്പോൾ",
    "author": "എം പി ജോസഫ് IAS",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 395,
    "bookNo": "M-25/269",
    "title": "എന്റെ സർവീസ് സ്റ്റോറി",
    "author": "മലയാറ്റൂർ രാമകൃഷ്ണൻ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 396,
    "bookNo": "M-26/355",
    "title": "ഗാന്ധിയുടെ സാക്ഷി. സെക്രട്ടറി വെങ്കിട്ട് രാം\n കല്യാണം കല്യാണം സംസാരിക്കുന്നു ",
    "author": "എം എൻ കാരശ്ശേരി ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 397,
    "bookNo": "M-27/754",
    "title": "ദൈവത്തിന്റെ ചാരന്മാർ",
    "author": "ജോസഫ് അന്നംക്കുട്ടി ജോസ്",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 398,
    "bookNo": "M-28/791",
    "title": "ദൈവത്തിന്റെ ചാരന്മാർ",
    "author": "ജോസഫ് അന്നംകുട്ടി ജോസ്",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 399,
    "bookNo": "M-29/800",
    "title": "ജീവിതം ഒരു മൊണാലിസച്ചിരിയാണ്",
    "author": "ദീപാനിശാന്ത്",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 400,
    "bookNo": "M-30/802",
    "title": "വംശം ദേശം സന്ദേശം",
    "author": "സയ്യിദ് ഹൈദരലി ശിഹാബ് തങ്ങൾ",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 401,
    "bookNo": "M-31/815",
    "title": "കുറ്റാന്വേഷണത്തിന്റെ കാണാപ്പുറങ്ങൾ",
    "author": "എൻ രാമചന്ദ്രൻ ഐ പി സ്",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 402,
    "bookNo": "M-32/820",
    "title": "പൂനാരങ്ങ",
    "author": "",
    "category": "ഓർമ്മ(M)"
  },
  {
    "serialNo": 403,
    "bookNo": "MP-1/103",
    "title": "മാപ്പിള മലബാർ",
    "author": "ഡോ ഹുസൈൻ രണ്ടത്താണി",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 404,
    "bookNo": "MP-2/105",
    "title": "TAHRIDAHLIL IMAN ALA JIHADI",
    "author": "ZAINUDDEEN MAKHDOOMI",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 405,
    "bookNo": "MP-3/108",
    "title": "കുമരംപുത്തൂർ സീതിക്കോയതങ്ങളും പാലക്കാടൻ പോരാളികളും ",
    "author": "നസ്രുദീൻ മണ്ണാർക്കാട് ",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 406,
    "bookNo": "MP-4/102",
    "title": "ചേറൂർ പടപ്പാട്ട് :കനൽ പഥങ്ങളിലെ ഇശൽ ജ്വാലകൾ",
    "author": "ഡോ. പി സക്കീർ ഹുസൈൻ",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 407,
    "bookNo": "MP-5/106",
    "title": "മലബാർ ചരിത്രം: പാഠവും പഠനവും",
    "author": "ഡോ മോയിൻ മലയമ്മ ",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 408,
    "bookNo": "MP-6/100",
    "title": "അറബി മലയാള സാഹിത്യം : അതിജീവനവും \nപാർശ്വവൽക്കരണവും\n",
    "author": "മുഹമ്മദ് ഖാസിം ഇ",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 409,
    "bookNo": "MP-7/99",
    "title": "ശുജായി മൊയ്‌ദു മുസ്‌ലിയാർ : \nധിഷ്ണു സമരം അതിജീവനം\n",
    "author": "ഡോ. പി സക്കീർ ഹുസൈൻ",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 410,
    "bookNo": "MP-8/160",
    "title": "ഫതഹൽ മുബീൻ",
    "author": "Qadi muhammad",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 411,
    "bookNo": "MP-9/107",
    "title": "സയ്യിദ് ഫള്ൽ പൂക്കോയ തങ്ങൾ, മമ്പുറം",
    "author": "മുഹമ്മദ് എ.ത്വാഹിർ",
    "category": "മാപ്പിള സാഹിത്യം"
  },
  {
    "serialNo": 412,
    "bookNo": "NF-1/15",
    "title": "കുമൈലിന്റെ പ്രാർഥന",
    "author": "എ.കെ. അബ്ദുൽ മജീദ്",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 413,
    "bookNo": "NF-2/16",
    "title": "ഫീഹിമാ ഫീഹി",
    "author": "ജലാലുദ്ദീൻ റൂമി",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 414,
    "bookNo": "NF-3/63",
    "title": "സ്നേഹസാമ്യാജാത്തിലെ രാജകുമാരി",
    "author": "മുഹമ്മദ്പാറന്ദർ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 415,
    "bookNo": "NF-4/62",
    "title": "മറിയമിന്റെ മകൻ",
    "author": "ഗിഫു മേലാറ്റൂർ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 416,
    "bookNo": "NF-5/61",
    "title": "ബാഗ്ദാദിന്റെ പേക്കിനാവ്",
    "author": "പുല്ലമ്പാറ ഷംസുദ്ദീൻ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 417,
    "bookNo": "NF-6/383",
    "title": "മസ്നവി ",
    "author": "ജലാലുദ്ധീൻ റൂമി / സി.ഹംസ ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 418,
    "bookNo": "NF-7/141",
    "title": "കോന്തല - വയനാടിന്റെ ആത്മകഥ ",
    "author": "കൽപറ്റ നാരായണൻ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 419,
    "bookNo": "NF-8/145",
    "title": "കോന്തല - വയനാടിന്റെ ആത്മകഥ ",
    "author": "കൽപറ്റ നാരായണൻ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 420,
    "bookNo": "NF-9/135",
    "title": "സ്വരാജ് ",
    "author": " അരവിന്ദ് കെജ്‌രിവാൾ / സ്മിത മീനാക്ഷി ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 421,
    "bookNo": "NF-10/143",
    "title": "നക്ഷത്രങ്ങളുടെ ചിരി ",
    "author": "അക്ബർ കക്കട്ടിൽ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 422,
    "bookNo": "NF-11/144",
    "title": "ബുദ്ധന്റെ ചിരി ",
    "author": "എം.പി വീരേന്ദ്രകുമാർ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 423,
    "bookNo": "NF-12/146",
    "title": "ജീവന്റെ പുസ്തകം - പരിസ്ഥിതി \nദർശനത്തിന് ഒരാമുഖം \n",
    "author": "പി.സുരേന്ദ്രൻ ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 424,
    "bookNo": "NF-13/109",
    "title": "തളിരിലകൾ ",
    "author": "ഫൈസൽ അഹ്സനി ഉളിയിൽ ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 425,
    "bookNo": "NF-14/115",
    "title": "ക്യാമ്പസ് ഓഫ് ക്യാമ്പസ് ",
    "author": "പ്രൊഫസർ എ പി അബ്ദുൽ വഹാബ്",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 426,
    "bookNo": "NF-15/110",
    "title": "ആരോടും ചൊല്ലാതെ",
    "author": "തോപ്പിൽ മുഹമ്മദ് മീരാൻ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 427,
    "bookNo": "NF-16/136",
    "title": "ഇന്ത്യയുടെ ചൈതന്യം - ",
    "author": "APJ Abdul Kalam",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 428,
    "bookNo": "NF-17/138",
    "title": "മഹാ പ്രളയം - ",
    "author": "ബി.സന്ധ്യ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 429,
    "bookNo": "NF-18/139",
    "title": "സൈലൻ്റ വാലി - ",
    "author": "സജി ജെയിംസ്",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 430,
    "bookNo": "NF-19/380",
    "title": "പുരോഗമന വിദ്യാഭ്യാസ ചിന്തകൾ - പി വി പുരുശോത്തമൻ",
    "author": "പി വി പുരുഷോത്തമൻ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 431,
    "bookNo": "NF-20/386",
    "title": "സ്നേഹത്തിൽ പൊതിഞ്ഞ പാർസൽ",
    "author": "ടി എം സി ഇബ്രാഹിം",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 432,
    "bookNo": "NF-21/261",
    "title": "ചോര പുരണ്ട വറ്റ്",
    "author": "സ്വാലിഹ ഫാത്തിമ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 433,
    "bookNo": "NF-22/789",
    "title": "ചോര പുരണ്ട വറ്റ്",
    "author": "സ്വാലിഹ ഫാത്തിമ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 434,
    "bookNo": "NF-23/790",
    "title": "കശ്മീർ അസം",
    "author": "കാസിം ഇരിക്കൂർ",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 435,
    "bookNo": "NF-24/843",
    "title": "ഒരു  പെയിൻറ് പണിക്കാരന്റെ ലോകസഞ്ചാരങ്ങൾ",
    "author": "",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 436,
    "bookNo": "NF-25/821",
    "title": "തരൂരോസോറസ്",
    "author": "",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 437,
    "bookNo": "NF-26/834",
    "title": "ആനന്ദ ലഹരി",
    "author": "",
    "category": "NON-FICTION(NF)"
  },
  {
    "serialNo": 438,
    "bookNo": "PO-1/397",
    "title": "കറുമ്പിയാട് ",
    "author": "തസ്‌ലിം കൂടരിഞ്ഞി ",
    "category": "കവിത"
  },
  {
    "serialNo": 439,
    "bookNo": "PO-2/398",
    "title": "പ്രണയത്തിനാൽ മാത്രം ",
    "author": "റഫീക്ക് അഹമ്മദ് ",
    "category": "കവിത"
  },
  {
    "serialNo": 440,
    "bookNo": "PO-3/399",
    "title": "പനിക്കൂണുകൾ ",
    "author": "അൽത്താഫ് പതിനാറുങ്ങൽ ",
    "category": "കവിത"
  },
  {
    "serialNo": 441,
    "bookNo": "PO- 4/48",
    "title": "നൂലു കോർത്ത രാത്രി",
    "author": "ഷബീർ അണ്ടത്തോട് ",
    "category": "കവിത"
  },
  {
    "serialNo": 442,
    "bookNo": "PH-1/66",
    "title": "ബീവി ഉമ്മു സലമ(റ)",
    "author": "അ ബ്ദുൽ വഹാബ് ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 443,
    "bookNo": "PH-2/80",
    "title": "ബീവി മറിയം (റ)",
    "author": "ഇബ്രാഹിം ടി എൻ പുരം",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 444,
    "bookNo": "PH-3/64",
    "title": "ബീവി ഉമ്മു സലമ (റ)",
    "author": "മുഹമ്മദ് പാറന്നൂര്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 445,
    "bookNo": "PH-4/59",
    "title": "പ്രവാചകന്റെ മദീന രാഷ്ട്രം സമൂഹം സമ്പദ് വ്യവസ്ഥ",
    "author": "ഡോ പി സക്കീർ ഹുസൈൻ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 446,
    "bookNo": "PH-5/76",
    "title": "നീനവായിലെ വെളിച്ചം",
    "author": "ഇർശാന അയ്യനാരി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 447,
    "bookNo": "PH-6/53",
    "title": "വാരിപ്പുണരേണ്ട വസ്ത്രങ്ങൾ",
    "author": "മുസ്തഫൽ ഫാളിലി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 448,
    "bookNo": "PH-7/86",
    "title": "ഹബീബിനെ പ്രണയിച്ചവൾ",
    "author": "റിസ്വാൻ അബൂബക്കർ അദനി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 449,
    "bookNo": "PH-8/427",
    "title": "മങ്കൂസ് മൗലിദ്",
    "author": "",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 450,
    "bookNo": "PH-9/437",
    "title": "കാത്തിരുന്ന പ്രവാചകൻ",
    "author": "കോടമ്പുഴ ബാവ മുസ്ലിയാർ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 451,
    "bookNo": "PH-10/400",
    "title": "മുഹമ്മദ് നബി",
    "author": "ലേഖന സമാഹാരം",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 452,
    "bookNo": "PH-11/37",
    "title": "മുഹമ്മദ് അവന്റെ തിരുദൂതർ",
    "author": "ആൻമേരി ഷിമ്മൽ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 453,
    "bookNo": "PH-12/415",
    "title": "മുഹമ്മദ്",
    "author": "ഹുസൈൻ ഗുബാഷ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 454,
    "bookNo": "PH-13/58",
    "title": "പ്രവാചകൻറെ മദീന",
    "author": "ഡോ പി സക്കീർ ഹുസൈൻ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 455,
    "bookNo": "PH-14/55",
    "title": "തിളങ്ങും തിരുകേശം",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റി പറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 456,
    "bookNo": "PH-15/566",
    "title": "മുഹമ്മദ് റസൂൽ",
    "author": "കാന്തപുരം എ പി അബൂബക്കർ മുസ്ലിയാർ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 457,
    "bookNo": "PH-16/250",
    "title": "ഉമ്മുൽ മുഅ്മിനീൻ ആയിശ (റ)",
    "author": "സഈദ് റമസാൻ ബൂത്വി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 458,
    "bookNo": "PH-17/67",
    "title": "വിശ്വാസികളുടെ ഉമ്മമാർ",
    "author": "സ്വാദിഖ് അൻവരി ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 459,
    "bookNo": "PH-18/92",
    "title": "അനുഗ്രഹത്തിന്റെ പ്രവാചകൻ യുഗാന്തരങ്ങളുടെയും",
    "author": "പി എ കെ മുഴപ്പാല",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 460,
    "bookNo": "PH-19/39",
    "title": "എൻറെ നബി",
    "author": "പി കെ മുഹമ്മദ് ശരീഫ് ഹുദവി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 461,
    "bookNo": "PH-20/54",
    "title": "നഅലെ മുബാറക്ക്",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 462,
    "bookNo": "PH-21/56",
    "title": "മദീന അനുരാഗത്തിന്റെ ആരാമം",
    "author": "ഒരു സംഘം ലേഖകർ ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 463,
    "bookNo": "PH-22/51",
    "title": "തിങ്കളിന്റെ തലപ്പാവ്",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 464,
    "bookNo": "PH-23/50",
    "title": "മുഹമ്മദ് നബിയുടെ നേതൃത്വം",
    "author": "ജോൺ അഡയർ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 465,
    "bookNo": "PH-24/45",
    "title": "പ്രവാചകാഭിധേയങ്ങൾ",
    "author": "പ്രൊഫ. അഹ്മദ് കുട്ടി ശിവപുരം",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 466,
    "bookNo": "PH-25/43",
    "title": "തിരുനബിയുടെ പാലായനം",
    "author": "സിപി ഷെഫീഖ് ബുഖാരി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 467,
    "bookNo": "PH-26/42",
    "title": "നിങ്ങളുടെ പ്രവാചകന്‍",
    "author": "ഫൈസൽ അഹ്സനി രണ്ടത്താണി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 468,
    "bookNo": "PH-27/90",
    "title": "ജീവിക്കുന്ന പ്രവാചകൻ",
    "author": "ഡോ മുഹമ്മദ് ഫാറൂഖ് ബുഖാരി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 469,
    "bookNo": "PH-28/87",
    "title": "നബി പ്രണയത്തിൻറെ നിഗൂഢ രഹസ്യങ്ങൾ",
    "author": "ഹബീബ് അലി അൽ ജിഫ്രി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 470,
    "bookNo": "PH-29/91",
    "title": "പ്രവാചകൻ ചിരിച്ച സന്ദർഭങ്ങൾ",
    "author": "അൽ സഅദ് മുഹമ്മദ് അബ്ദുല്ല",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 471,
    "bookNo": "PH-30/89",
    "title": "പ്രവാചകാഭിധേയങ്ങൾ",
    "author": "പ്രൊഫ. അഹ്മദ് കുട്ടി ശിവപുരം",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 472,
    "bookNo": "PH-32/248",
    "title": "റസൂലിന്റെ കൂട്ടുകാരൻ",
    "author": "ജമാൽ മുഹമ്മദ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 473,
    "bookNo": "PH-31/247",
    "title": "നബിയെ പരിചയപ്പെടുക",
    "author": "ഇബ്രാഹിം പുത്തൂർ ഫൈസി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 474,
    "bookNo": "PH-33/246",
    "title": "കഥയുള്ള കത്തുകൾ",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 475,
    "bookNo": "PH-34/245",
    "title": "റസൂലിന്റെ ബാല്യം",
    "author": "സയ്യിദ് സ്വലാഹുദ്ദീൻ ബുഖാരി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 476,
    "bookNo": "PH-35/244",
    "title": "ലോകം കാത്തിരുന്ന പ്രവാചകൻ",
    "author": "കൊടമ്പുഴ ബാവ മുസ്ലിയാർ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 477,
    "bookNo": "PH-36/243",
    "title": "മുഹമ്മദ് ദ ലാസ്റ്റ് പ്രൊഫറ്റ്",
    "author": "എ പി കുഞ്ഞാമു",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 478,
    "bookNo": "PH-37/154",
    "title": "യസ്രിബ്  വിളിച്ചു i വരൂ...",
    "author": "എ കെ അബ്ദുൽ മജീദ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 479,
    "bookNo": "PH-38/153",
    "title": "മുത്ത് നബിയുടെ പാഠശാല",
    "author": "മുഹിയുദ്ദീൻ സഖാഫി ചീക്കോട്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 480,
    "bookNo": "PH-39/83",
    "title": "മുഹമ്മദ്",
    "author": "കാരൻ ആംസ്ട്രോങ്ങ് /എ പി കുഞ്ഞാമു",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 481,
    "bookNo": "PH-40/258",
    "title": "റസൂലിന്റെ പൂക്കൾ",
    "author": "സയ്യിദ് സലാഹുദ്ധീൻ ബുഖാരി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 482,
    "bookNo": "PH-41/251",
    "title": "മരണത്തിന്റെ താഴ് വരകൾ",
    "author": "ഇ ടി ഹുസൈൻ ഹുദവി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 483,
    "bookNo": "PH-42/85",
    "title": "തിരുനബി കഥകൾ",
    "author": "പട്ടണക്കാട് അബ്ദുൽ ഖാദർ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 484,
    "bookNo": "PH-43/47",
    "title": "നബി പ്രണയത്തിൻറെ നിഗൂഢ രഹസ്യങ്ങൾ",
    "author": "ഹബീബ് അലി അൽജിഫ്രി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 485,
    "bookNo": "PH-44/81",
    "title": "മുഹമ്മദ്",
    "author": "മാർട്ടിൻ ലിങ്ങ്സ് / കെ.ടി സൂപ്പി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 486,
    "bookNo": "PH-45/82",
    "title": "മുഹമ്മദ് നബി ചരിത്രസ്മരണകൾ",
    "author": "എം പി അബ്ദുല്ല ഫൈസി നെക്രാജ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 487,
    "bookNo": "PH-46/40",
    "title": "മുഹമ്മദ് ദ ലാസ്റ്റ് പ്രൊഫറ്റ്",
    "author": "എ പി കുഞ്ഞാമു",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 488,
    "bookNo": "PH-47/41",
    "title": "ജീവിക്കുന്ന പ്രവാചകൻ",
    "author": "ഡോ മുഹമ്മദ് ഫാറൂഖ് ബുഖാരി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 489,
    "bookNo": "PH-48/77",
    "title": "മൊഞ്ചുള്ള മോതിരം",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 490,
    "bookNo": "PH-49/74",
    "title": "ഇഷ്ടതോഴയരുടെ ഈത്തപ്പനയോലകൾ",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 491,
    "bookNo": "PH-50/79",
    "title": "മദീന അനുരാഗത്തിന്റെ ആരാമം",
    "author": "ഒരു സംഘം ലേഖകർ ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 492,
    "bookNo": "PH-51/75",
    "title": "കാത്തിരിപ്പിന്റെ മധുരം",
    "author": "ശഫീഖ് വഴിപാറ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 493,
    "bookNo": "PH-52/60",
    "title": "പൊലിമയുള്ള പച്ച ഖുബ്ബ",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 494,
    "bookNo": "PH-53/38",
    "title": "തിരുനബി സ്നേഹ വഴികൾ",
    "author": "കെ.കെ മുഹമ്മദ് ബാഖവി",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 495,
    "bookNo": "PH-54/49",
    "title": "പ്രകൃതിയുടെ പ്രവാചകൻ",
    "author": "മുബശ്ശിർ മുഹമ്മദ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 496,
    "bookNo": "PH-55/152",
    "title": "പ്രകൃതിയുടെ പ്രവാചകൻ",
    "author": "മുബശ്ശിർ മുഹമ്മദ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 497,
    "bookNo": "PH-56/151",
    "title": "സ്നേഹമാണെൻ്റെ റസൂൽ",
    "author": "ഇല്യാസ് ഇർഫാനി ചെറിയമുണ്ടം",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 498,
    "bookNo": "PH-57/150",
    "title": "കാരുണ്യത്തിന്റെ പ്രവാചകൻ",
    "author": "നാഥുറാം",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 499,
    "bookNo": "PH-58/148",
    "title": "മുത്ത് നബിയും പനിനീർ പൂവും",
    "author": "കെ അബൂബക്കർ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 500,
    "bookNo": "PH-59/149",
    "title": "റസൂലിന്റെ പള്ളികൾ",
    "author": "അബ്ദുല്ല സഖാഫി വിളത്തൂര്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 501,
    "bookNo": "PH-60/147",
    "title": "മരുഭൂമിയിലെ പ്രവാചകൻ",
    "author": "കെ.എൽ ഗൗബ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 502,
    "bookNo": "PH-61/12",
    "title": "തീക്കടൽ കടന്ന ത്യാഗം",
    "author": "എം. അബ്ബാസ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 503,
    "bookNo": "PH-62/391",
    "title": "മുത്തുനബിയുടെ കുട്ടിക്കാലം",
    "author": "മുഹമ്മദ് പാറന്നൂര്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 504,
    "bookNo": "PH-63/46",
    "title": "ബീവി ഉമ്മുസുലൈം",
    "author": "മുഹമ്മദ് പാറന്നൂര്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 505,
    "bookNo": "PH-64/88",
    "title": "THE PROOF OF PROPHETHOOD",
    "author": "HÜSEYİN HİLMİ IŞIK",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 506,
    "bookNo": "PH-65/794",
    "title": "തിരുസവിധം നബി അനുചരരുടെ ജീവിതം",
    "author": "ഒരു സംഘം ലേഖകർ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 507,
    "bookNo": "PH-66/795",
    "title": "അനുരാഗികളുടെ റസൂൽ",
    "author": "ശരീഫ് സിദ്ദീഖി ബ്രിസ്ബൻ",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 508,
    "bookNo": "PH-67/803",
    "title": "തിരുശേഷിപ്പുകൾ - ചരിത്രം , മഹത്വം",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപ്പറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 509,
    "bookNo": "PH-68/807",
    "title": "ദൂസലാം",
    "author": "മുസ്തഫൽ ഫാളിലി കരീറ്റിപ്പറമ്പ്",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 510,
    "bookNo": "PH-69/812",
    "title": "",
    "author": "",
    "category": "PROPHET HISTORY"
  },
  {
    "serialNo": 511,
    "bookNo": "R-1/403",
    "title": "L D ക്ലർക്ക്-റാങ്ക് ഫയൽ 2019",
    "author": "ടാലന്റ് അക്കാദമി ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 512,
    "bookNo": "R-2/407",
    "title": "Oxford language referance-1",
    "author": "Jonathan law",
    "category": "REFERENCES"
  },
  {
    "serialNo": 513,
    "bookNo": "R-3/408",
    "title": "Oxford quotations and proverbs -2",
    "author": "Susan Ratclifee",
    "category": "REFERENCES"
  },
  {
    "serialNo": 514,
    "bookNo": "R-4/409",
    "title": "Oxford dictionary and thesaurus-3",
    "author": "Julia Ellioti",
    "category": "REFERENCES"
  },
  {
    "serialNo": 515,
    "bookNo": "R-5/410",
    "title": "Oxford picture dictionary english arabic",
    "author": "Jayme adelson",
    "category": "REFERENCES"
  },
  {
    "serialNo": 516,
    "bookNo": "R-6/411",
    "title": "മലയാളം -ഉർദു, ഉർദു-മലയാളം നിഘണ്ടു",
    "author": "മുഹമ്മദ് അസ്ആബ് ഹുസൈൻ അൽ ഖാസിമി ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 517,
    "bookNo": "R-7/648",
    "title": "ENDLESS BLISS-1",
    "author": "SIDDIK GUMUS",
    "category": "REFERENCES"
  },
  {
    "serialNo": 518,
    "bookNo": "R-8/649",
    "title": "ENDLESS BLISS-1 ",
    "author": "HUSEYIN HILMI ISIK",
    "category": "REFERENCES"
  },
  {
    "serialNo": 519,
    "bookNo": "R-9/650",
    "title": "ENDLESS BLISS-2",
    "author": "HUSEYIN HILMI ISIK",
    "category": "REFERENCES"
  },
  {
    "serialNo": 520,
    "bookNo": "R-10/651",
    "title": "ENDLESS BLISS-3",
    "author": "HUSEYIN HILMI ISIK",
    "category": "REFERENCES"
  },
  {
    "serialNo": 521,
    "bookNo": "R-11/652",
    "title": "ENDLESS BLISS-4",
    "author": "HUSEYIN HILMI ISIK",
    "category": "REFERENCES"
  },
  {
    "serialNo": 522,
    "bookNo": "R-12/653",
    "title": "ENDLESS BLISS-5",
    "author": "HUSEYIN HILMI ISIK",
    "category": "REFERENCES"
  },
  {
    "serialNo": 523,
    "bookNo": "R-13/654",
    "title": "ENDLESS BLISS-6",
    "author": "HUSEYIN HILMI ISIK ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 524,
    "bookNo": "R-14/655",
    "title": "COULD NOT ANSWER-13",
    "author": "ISHAQ EFENDI",
    "category": "REFERENCES"
  },
  {
    "serialNo": 525,
    "bookNo": "R-15/656",
    "title": "ETHICS OF ISLAM-17",
    "author": "HUSEYIN HILMI ISIK",
    "category": "REFERENCES"
  },
  {
    "serialNo": 526,
    "bookNo": "R-16/657",
    "title": "ISLAM'S REFORMERS-19",
    "author": "HUSEYIN HILMI ISIK",
    "category": "REFERENCES"
  },
  {
    "serialNo": 527,
    "bookNo": "R-17/660",
    "title": "Urdu Software",
    "author": "NCPUL",
    "category": "REFERENCES"
  },
  {
    "serialNo": 528,
    "bookNo": "R-18/632",
    "title": "Indian Government and Politics",
    "author": "Pondychery University",
    "category": "REFERENCES"
  },
  {
    "serialNo": 529,
    "bookNo": "R-19/582",
    "title": "Principles of Public Administration ",
    "author": "Pondichery University",
    "category": "REFERENCES"
  },
  {
    "serialNo": 530,
    "bookNo": "R-20/130",
    "title": "The Hindu Editorials 2022",
    "author": "The Hindu",
    "category": "REFERENCES"
  },
  {
    "serialNo": 531,
    "bookNo": "R-21/658",
    "title": "THE FAMILY LIFE OF ISLAM",
    "author": "SAYYID SAEED",
    "category": "REFERENCES"
  },
  {
    "serialNo": 532,
    "bookNo": "R-22/659",
    "title": "INDIAN ART AND CULTURE",
    "author": "NITIN SINGHANIYA",
    "category": "REFERENCES"
  },
  {
    "serialNo": 533,
    "bookNo": "R-23/692",
    "title": "General Studies for Civil Services",
    "author": "Dr. Savendar Sing",
    "category": "REFERENCES"
  },
  {
    "serialNo": 534,
    "bookNo": "R-24/661",
    "title": "PHYSICAL GEOGRAPHY",
    "author": "MAJD HUSAIN ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 535,
    "bookNo": "R-25/662",
    "title": "INDIAN AND WORLD GEOGRAPHY-1",
    "author": "DR KHULLAR",
    "category": "REFERENCES"
  },
  {
    "serialNo": 536,
    "bookNo": "R-26/663",
    "title": "LOGICAL REASONING",
    "author": "DR R S AGGARWAL",
    "category": "REFERENCES"
  },
  {
    "serialNo": 537,
    "bookNo": "R-27/664",
    "title": "GENERAL STUDIES PAPER II FOR CIVIL SERVICE",
    "author": "EDGAR THORP",
    "category": "REFERENCES"
  },
  {
    "serialNo": 538,
    "bookNo": "R-28/665",
    "title": "INDIAN ECONOMY",
    "author": "RAMESH SINGH",
    "category": "REFERENCES"
  },
  {
    "serialNo": 539,
    "bookNo": "R-29/666",
    "title": "CERTIFICATE PHYSICAL AND HUMAN GEOGRAPHY",
    "author": "GOHCHENG",
    "category": "REFERENCES"
  },
  {
    "serialNo": 540,
    "bookNo": "R-30/693",
    "title": "Cambridge Phrasal Verb Dictionary",
    "author": "Pr. Michael Carthy",
    "category": "REFERENCES"
  },
  {
    "serialNo": 541,
    "bookNo": "R-31/668",
    "title": "INTERNATIONAL RELATIONS ",
    "author": "PAVNEET SINGH",
    "category": "REFERENCES"
  },
  {
    "serialNo": 542,
    "bookNo": "R-32/669",
    "title": "ACTIVE ENGLISH-FOR COMPETITIVE EXAM",
    "author": "DR N GANGADHARAN NAIR",
    "category": "REFERENCES"
  },
  {
    "serialNo": 543,
    "bookNo": "R-33/670",
    "title": "NON-VERBAL REASONING ",
    "author": "DR R S AGGARWAL",
    "category": "REFERENCES"
  },
  {
    "serialNo": 544,
    "bookNo": "R-34/671",
    "title": "WORLD HISTORY",
    "author": "KRISHNA REDDY",
    "category": "REFERENCES"
  },
  {
    "serialNo": 545,
    "bookNo": "R-35/672",
    "title": "GEOGRAPHY",
    "author": "MAJD HUSAIN",
    "category": "REFERENCES"
  },
  {
    "serialNo": 546,
    "bookNo": "R-36/673",
    "title": "INTERNAL SECURITY",
    "author": "M KARTHIKEYAN",
    "category": "REFERENCES"
  },
  {
    "serialNo": 547,
    "bookNo": "R-37/696",
    "title": "India 2022",
    "author": "Roma Chattarjee",
    "category": "REFERENCES"
  },
  {
    "serialNo": 548,
    "bookNo": "R-38/675",
    "title": "CIVIL SERVICE PAREEKSHAYILE COMPULSARY \nMALAYALAM",
    "author": "JOBIN S KOTTARAM ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 549,
    "bookNo": "R-39/676",
    "title": "INTERNAL SECURITY",
    "author": "ASHOK KUMAR,VIPUL",
    "category": "REFERENCES"
  },
  {
    "serialNo": 550,
    "bookNo": "R-40/677",
    "title": "ETHICS INTEGRITY AND APTITUDE ",
    "author": "M KARTHIKEYAN",
    "category": "REFERENCES"
  },
  {
    "serialNo": 551,
    "bookNo": "R-41/678",
    "title": "VERBAL REASONING",
    "author": "DR R S AGGARWAL",
    "category": "REFERENCES"
  },
  {
    "serialNo": 552,
    "bookNo": "R-42/679",
    "title": "CONSTITUTION OF INDIA",
    "author": "DURGA DAS BASU",
    "category": "REFERENCES"
  },
  {
    "serialNo": 553,
    "bookNo": "R-43/680",
    "title": "SOCIAL CHANGE IN MODERN INDIA ",
    "author": "M N SRINIVAS",
    "category": "REFERENCES"
  },
  {
    "serialNo": 554,
    "bookNo": "R-44/638",
    "title": "Tapestry-1",
    "author": "Rebecca. L. Oxford",
    "category": "REFERENCES"
  },
  {
    "serialNo": 555,
    "bookNo": "R-45/636",
    "title": "Tapestry - 3",
    "author": "Rabecca. L. Oxford",
    "category": "REFERENCES"
  },
  {
    "serialNo": 556,
    "bookNo": "R-46/683",
    "title": "The Wonder, that was India",
    "author": "A.L. Basham",
    "category": "REFERENCES"
  },
  {
    "serialNo": 557,
    "bookNo": "R-47/695",
    "title": "The Elements of Mentoring",
    "author": "W. Brad Johnson",
    "category": "REFERENCES"
  },
  {
    "serialNo": 558,
    "bookNo": "R- 48/685",
    "title": "An advanced Course in English Grammar and Compostion",
    "author": "Pr. E. J. Carri",
    "category": "REFERENCES"
  },
  {
    "serialNo": 559,
    "bookNo": "R-49/694",
    "title": "English Grammar and Composition",
    "author": "S. C. Gupta",
    "category": "REFERENCES"
  },
  {
    "serialNo": 560,
    "bookNo": "R-50/687",
    "title": "The First 100 Editorials 1878-1978",
    "author": "The Hindu",
    "category": "REFERENCES"
  },
  {
    "serialNo": 561,
    "bookNo": "R-51/688",
    "title": "The Second 100 Editorials 1978-2016",
    "author": "The Hindu",
    "category": "REFERENCES"
  },
  {
    "serialNo": 562,
    "bookNo": "R-52/689",
    "title": "Book of Editorials 2017",
    "author": "The Hindu",
    "category": "REFERENCES"
  },
  {
    "serialNo": 563,
    "bookNo": "R-53/690",
    "title": "Book of Editorials 2018",
    "author": "The Hindu",
    "category": "REFERENCES"
  },
  {
    "serialNo": 564,
    "bookNo": "R-54/691",
    "title": "Despatcher 2017-18",
    "author": "The Hindu",
    "category": "REFERENCES"
  },
  {
    "serialNo": 565,
    "bookNo": "R-55/682",
    "title": "INDIA 2023",
    "author": "MINISTER OF INFORMATION",
    "category": "REFERENCES"
  },
  {
    "serialNo": 566,
    "bookNo": "R-56/686",
    "title": "General Knowledge, Mock Test",
    "author": "",
    "category": "REFERENCES"
  },
  {
    "serialNo": 567,
    "bookNo": "R-56/687",
    "title": "ഇസ്ലാമിക വിജ്യാനാ കോശം -1",
    "author": "ടി. കെ അബ്ദുള്ള ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 568,
    "bookNo": "R-58/701",
    "title": "ഇസ്ലാമിക വിഞ്യന കോശം -2",
    "author": "ടി. കെ അബ്ദുള്ള ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 569,
    "bookNo": "R-59/702",
    "title": "ഇസ്ലാമിക വിഞ്യന കോശം -3",
    "author": "ടി. കെ അബ്ദുള്ള ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 570,
    "bookNo": "R-60/703",
    "title": "ഇസ്ലാമിക വിഞ്യന കോശം -4",
    "author": "ടി കെ അബ്ദുല്ല ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 571,
    "bookNo": "R-61/704",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം-5",
    "author": "ടി കെ അബ്ദുള്ള ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 572,
    "bookNo": "R-62/705",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം -6",
    "author": "ടി കെ അബ്ദുള്ള",
    "category": "REFERENCES"
  },
  {
    "serialNo": 573,
    "bookNo": "R-63/706",
    "title": "ഇസ്‌ലാമിക വിഞാനകോശം 7",
    "author": "ടി. കെ അബ്ദുല്ല ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 574,
    "bookNo": "R.-64/707",
    "title": "ഇസ്‌ലാമിക വിജ്ഞാന കോശം 8",
    "author": "ടി കെ അബ്ദുല്ല ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 575,
    "bookNo": "R-65/708",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം 9",
    "author": "ടി കെ അബ്ദുല്ല ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 576,
    "bookNo": "R-66/709",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം 10 ",
    "author": "ടി കെ അബ്ദുല്ല ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 577,
    "bookNo": "R-67/710",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം 11",
    "author": "ടി കെ അബ്ദുല്ല ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 578,
    "bookNo": "R-68/711",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം 12 ",
    "author": "ടി കെ അബ്ദുല്ല ",
    "category": "REFERENCES"
  },
  {
    "serialNo": 579,
    "bookNo": "R-69/712",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം 13 ",
    "author": "ടി കെ അബ്ദുല്ല",
    "category": "REFERENCES"
  },
  {
    "serialNo": 580,
    "bookNo": "R-70/713",
    "title": "ഇസ്ലാമിക വിജ്ഞാന കോശം 14",
    "author": "ഡോ. കൂട്ടിൽ മുഹമ്മദ് അലി",
    "category": "REFERENCES"
  },
  {
    "serialNo": 581,
    "bookNo": "S-1/218",
    "title": "ഭാർഗവീ നിലയം ",
    "author": "വൈക്കം മുഹമ്മദ്‌ ബഷീർ ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 582,
    "bookNo": "S-2/219",
    "title": "വിശപ്പ് ",
    "author": "വൈക്കം മുഹമ്മദ്‌ ബഷീർ ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 583,
    "bookNo": "S-3/221",
    "title": "ഭൂമിയുടെ അവകാശികൾ",
    "author": "വൈക്കം മുഹമ്മദ് ബഷീർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 584,
    "bookNo": "S-4/222",
    "title": "ആനപ്പൂട",
    "author": " ബഷീർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 585,
    "bookNo": "S-5/223",
    "title": "ഹിഗ്വിറ്റി",
    "author": "എൻ എസ് മാധവൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 586,
    "bookNo": "S-6/639",
    "title": "പ്രവാചകൻ ",
    "author": "ഖലീൽ ജിബ്രാൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 587,
    "bookNo": "S-7/224",
    "title": "കുന്തിരിക്കത്തിന്റെ മണമുള്ള ദിവസം",
    "author": "ബാബു കുഴിമറ്റം",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 588,
    "bookNo": "S-8/225",
    "title": "മിനിക്കഥകൾ , കവിതകൾ",
    "author": "എഡി.സുഭാഷ് ചന്ദ്രൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 589,
    "bookNo": "S-9/226",
    "title": "തിരഞ്ഞെടുത്ത കഥകൾ",
    "author": "പി.കെ പാറക്കടവ്",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 590,
    "bookNo": "S-10/227",
    "title": "ഗന്ധർവ്വൻ",
    "author": "വി.ആർ സുധീഷ്",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 591,
    "bookNo": "S-11/637",
    "title": "ഡിസി ഫലിതങ്ങൾ ",
    "author": "അരവിന്ദൻ കെ എസ് മംഗലം ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 592,
    "bookNo": "S-12/229",
    "title": "കഥകൾ",
    "author": "സുഭാഷ് ചന്ദ്രൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 593,
    "bookNo": "S-13/230",
    "title": "ഈറ്റ്സൺ, ഡ്രിങ്ക്സെൻ, സ്ലീപ്സെൻ ",
    "author": "വി.കൃഷ്ണകുമാർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 594,
    "bookNo": "S-14/231",
    "title": "മഴക്കണ്ണാടി",
    "author": "ഇന്നസെന്റ്",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 595,
    "bookNo": "S-15/387",
    "title": "അമ്മമ്മ ",
    "author": "പി.സുരേന്ദ്രൻ ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 596,
    "bookNo": "S-16/233",
    "title": "ഒരു പാട്ടിന്റെ ദൂരം",
    "author": "ശിഹാബുദ്ദീൻ പൊഴുത്തും കടവ് ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 597,
    "bookNo": "S-17/234",
    "title": "അന്തർ വാഹിനി",
    "author": "എസ്. കെ പൊറ്റക്കാട്",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 598,
    "bookNo": "S-18/237",
    "title": "തീവണ്ടി പറഞ്ഞ കഥകൾ",
    "author": "നൗഷാദ്നൗഷാദ്",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 599,
    "bookNo": "S-19/392",
    "title": "ഉറുമ്പ് ജീവിതം (അതിജീവനത്തിന്റെ കഥ )",
    "author": "മയൂഖി ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 600,
    "bookNo": "S-20/238",
    "title": "വാശുപതം",
    "author": "ഇ . സന്തോഷ് കുമാർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 601,
    "bookNo": "S-21/381",
    "title": "നല്ല മാഷും നല്ല മിസ്സും",
    "author": "A R കൊടിയത്തൂർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 602,
    "bookNo": "S-22/241",
    "title": "അമ്മ വീട് ",
    "author": "പി. സുരേന്ദ്രൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 603,
    "bookNo": "S-23/239",
    "title": "ജലസന്ധി",
    "author": "പി. സുരേന്ദ്രൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 604,
    "bookNo": "S-24/240",
    "title": "ഇലകളിൽ കാറ്റ് തൊടുമ്പോൾ",
    "author": "പി. സുരേന്ദ്രൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 605,
    "bookNo": "S-25/444",
    "title": "ഈസയും കെ. പി ഉമ്മറും",
    "author": "ശിഹാബുദ്ദീൻ പൊഴുത്തും കടവ്",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 606,
    "bookNo": "S-26/186",
    "title": "     വൈക്കം മുഹമ്മദ് ബഷീർ ജന്മദിനം.  ",
    "author": "എം എൻ വിജയൻ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 607,
    "bookNo": "S- 27/183",
    "title": " പശു           ",
    "author": "   കെപി അബൂബക്കർ ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 608,
    "bookNo": "S- 28/193",
    "title": "ഭൂമിയുടെ അവകാശികൾ",
    "author": "വൈക്കം മുഹമ്മദ് ബഷീർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 609,
    "bookNo": "S-29/187",
    "title": " ബിരിയാണി. ",
    "author": "        സന്തോഷ് ഏച്ചിക്കാനം",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 610,
    "bookNo": "S-30/197",
    "title": "ചിരിക്കുന്ന മരപ്പാവ  ",
    "author": "വൈക്കം മുഹമ്മദ് ബഷീർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 611,
    "bookNo": "S-31/214",
    "title": " വിലക്കപ്പെട്ട കനിയും മറ്റു കഥകളും",
    "author": "ഗീദ് മോപസാങ്",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 612,
    "bookNo": "S-32/472",
    "title": "കാടിൻറെ നടുക്കൊരു മരം",
    "author": " ദേവദാസ് വി എം",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 613,
    "bookNo": "s-33 /235",
    "title": "റൂമി പറഞ്ഞ കഥകൾ",
    "author": "അഷിത",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 614,
    "bookNo": "S-34/220",
    "title": "വിശ്വാവിഖ്യാതമായ മൂക്ക് ",
    "author": "വൈക്കം മുഹമ്മദ് ബഷീർ ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 615,
    "bookNo": "S-35/228",
    "title": "സറൗണ്ട് സിസ്റ്റം",
    "author": "ഷഫീക് മുസ്തഫ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 616,
    "bookNo": "S-36/743",
    "title": "ടോട്ടോ-ചാൻ",
    "author": "തെത് സുകോ കുറോയാനഗി /അൻവർ അലി",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 617,
    "bookNo": "S-37/744",
    "title": "ടോട്ടോ-ചാൻ",
    "author": "തെത് സുകോ കുറോയാനഗി /അൻവർ അലി",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 618,
    "bookNo": "S-38/748",
    "title": "ബിരിയാണി",
    "author": "സന്തോഷ് ഏച്ചിക്കാനം",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 619,
    "bookNo": "S-39/749",
    "title": "ബിരിയാണി",
    "author": "സന്തോഷ് ഏച്ചിക്കാനം",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 620,
    "bookNo": "S-40/766",
    "title": "തേന്മാവ്",
    "author": "ബഷീർ",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 621,
    "bookNo": "S-41/837",
    "title": "ഹൂവിനു ശേഷം ഹൂ",
    "author": "V K N",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 622,
    "bookNo": "S-42/827",
    "title": "രാച്ചിയമ്മ ",
    "author": "",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 623,
    "bookNo": "S-43/844",
    "title": "മധുപാലിൻറെ കഥകൾ",
    "author": "",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 624,
    "bookNo": "S-44/840",
    "title": "കാഫ്ക 50 കഥകൾ",
    "author": "",
    "category": "കഥ(S)"
  },
  {
    "serialNo": 625,
    "bookNo": "SE-1/623",
    "title": "THE HIDDEN POOL",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 626,
    "bookNo": "SE-2/626",
    "title": "THE ELEPHANT AND THE CASSOWARY",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 627,
    "bookNo": "SE-3/627",
    "title": "THE ESSENTIAL COLLECTION ",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 628,
    "bookNo": "SE-6/555",
    "title": "THIS IS HOW  IT TOOK PLACE",
    "author": "RUDRAKSHI BHATTACHAREJEE",
    "category": "Story(SE)"
  },
  {
    "serialNo": 629,
    "bookNo": "SE-4/556",
    "title": "THE OGRE OF OGLE FORT",
    "author": "EVA IBBOTSON",
    "category": "Story(SE)"
  },
  {
    "serialNo": 630,
    "bookNo": "SE-5/557",
    "title": "YOLO",
    "author": "LAUREN MYRACLE",
    "category": "Story(SE)"
  },
  {
    "serialNo": 631,
    "bookNo": "SE-7/558",
    "title": "GREAT SHOT STORIES OF LEO TOLSTOY",
    "author": "LEO TOLSTOY",
    "category": "Story(SE)"
  },
  {
    "serialNo": 632,
    "bookNo": "SE-8/561",
    "title": "RAVANPUTR MEGHNAD",
    "author": "KEVIN MISSAL",
    "category": "Story(SE)"
  },
  {
    "serialNo": 633,
    "bookNo": "SE-9/562",
    "title": "COMPLETE WORKS OF KAHLIL GIBRAN",
    "author": "KAHLIL GIBRAN ",
    "category": "Story(SE)"
  },
  {
    "serialNo": 634,
    "bookNo": "SE-10/ 563",
    "title": "GREAT WORKS OF VIRGINA WOOLF",
    "author": "VIRGINA WOOLF",
    "category": "Story(SE)"
  },
  {
    "serialNo": 635,
    "bookNo": "SE-11/564",
    "title": "THE BOOK OF GUSTY WOMEN ",
    "author": "HILLARY RODHAM CLINTON , CHELSE  CLINTON ",
    "category": "Story(SE)"
  },
  {
    "serialNo": 636,
    "bookNo": "SE-12/565",
    "title": "JUNGLE NAMA ",
    "author": "AMITAD GHOSH",
    "category": "Story(SE)"
  },
  {
    "serialNo": 637,
    "bookNo": "SE-13-/628",
    "title": "FAIRY TRESSURE",
    "author": "GWYNETH REES",
    "category": "Story(SE)"
  },
  {
    "serialNo": 638,
    "bookNo": "SE-14/630",
    "title": "BEST CLASSIC SHORT STORIES FOR CHILDREN",
    "author": "HARPER LOLLINS BOOKS",
    "category": "Story(SE)"
  },
  {
    "serialNo": 639,
    "bookNo": "SE-15/631",
    "title": "THE BLUE UMBRELLA",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 640,
    "bookNo": "SE-16/629",
    "title": "TROUBLE AT TABLE - 5",
    "author": "TOM WATSON",
    "category": "Story(SE)"
  },
  {
    "serialNo": 641,
    "bookNo": "SE-17/550",
    "title": "COMPLETE WORKS OF SHERLOCK HOLMS-VOL-1",
    "author": "SIR ARTHUR CONAN DOYLE",
    "category": "Story(SE)"
  },
  {
    "serialNo": 642,
    "bookNo": "SE-18/551",
    "title": "COMPLETE WORKS OF SHERLOCK HOLMS-VOL-2",
    "author": "SIR ARTHUR CONAN DOYLE",
    "category": "Story(SE)"
  },
  {
    "serialNo": 643,
    "bookNo": "SE-19/553",
    "title": " HARRY POTTER AND THE CHAMBER OF SECRETS",
    "author": "J K ROWLING",
    "category": "Story(SE)"
  },
  {
    "serialNo": 644,
    "bookNo": "SE-20/554",
    "title": "HARRY POTTER AND THE PRISONER OF AZKABAN",
    "author": "J K ROWLING",
    "category": "Story(SE)"
  },
  {
    "serialNo": 645,
    "bookNo": "SE-21/624",
    "title": "ALL ROADS LEAD TO GANGA",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 646,
    "bookNo": "SE-22/625",
    "title": "ALL ROADS LEAD TO GANGA",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 647,
    "bookNo": "SE-23/559",
    "title": "WILLAM AT THE WAR",
    "author": "RICHMAL CROMPTON",
    "category": "Story(SE)"
  },
  {
    "serialNo": 648,
    "bookNo": "SE-24/620",
    "title": "THE ROOM ON THE ROOF",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 649,
    "bookNo": "SE-25/771",
    "title": "HARRY POTTER AND THE PRISONER OF AZKABAN",
    "author": "J K ROWLING",
    "category": "Story(SE)"
  },
  {
    "serialNo": 650,
    "bookNo": "SE-26/",
    "title": "",
    "author": "",
    "category": "Story(SE)"
  },
  {
    "serialNo": 651,
    "bookNo": "SE-27/",
    "title": "",
    "author": "",
    "category": "Story(SE)"
  },
  {
    "serialNo": 652,
    "bookNo": "SE-28/621",
    "title": "LEGENDS OF THE HILL",
    "author": "RUSKIN BOND",
    "category": "Story(SE)"
  },
  {
    "serialNo": 653,
    "bookNo": "SK-1/405",
    "title": "എം. എ. അബ്ദുൽ ഖദിർ മുസ്‌ലിയാർ\n സംയുക്ത കൃതികൾ -വോളിയം -1\n",
    "author": "ഓ. എം തരുവണ ",
    "category": "സംയുക്ത കൃതികൾ"
  },
  {
    "serialNo": 654,
    "bookNo": "SK-2/78",
    "title": "എം. എ. അബ്ദുൽ ഖദിർ മുസ്‌ലിയാർ\n സംയുക്ത കൃതികൾ -വോളിയം -2\n",
    "author": "ഓ. എം തരുവണ ",
    "category": "സംയുക്ത കൃതികൾ"
  },
  {
    "serialNo": 655,
    "bookNo": "SK-3/313",
    "title": "എം. എ. അബ്ദുൽ ഖദിർ മുസ്‌ലിയാർ\n സംയുക്ത കൃതികൾ -വോളിയം -3\n",
    "author": "ഓ. എം തരുവണ ",
    "category": "സംയുക്ത കൃതികൾ"
  },
  {
    "serialNo": 656,
    "bookNo": "SC-1/13",
    "title": "എൻ എൽ പി എന്ന വിജയ മന്ത്രം",
    "author": "പ്രൊഫസർ പി എ വർഗീസ്",
    "category": "SCIENCE"
  },
  {
    "serialNo": 657,
    "bookNo": "SC-2/635",
    "title": "A BRIEF HISTORY OF TIME",
    "author": "STEPHEN HAWKING",
    "category": "SCIENCE"
  },
  {
    "serialNo": 658,
    "bookNo": "SC-3/301",
    "title": "അവസരങ്ങൾ വെല്ലുവിളികൾ",
    "author": "എ.പി.ജെ അബ്ദുൽ കലാം",
    "category": "SCIENCE"
  },
  {
    "serialNo": 659,
    "bookNo": "ST-1/131",
    "title": "മതരാഷ്ട്ര വാദവും ഖിലാഫത്തും",
    "author": "ഡോ ഉമറുൽ ഫാറൂഖ് സഖാഫി",
    "category": "STUDY"
  },
  {
    "serialNo": 660,
    "bookNo": "ST-2/120",
    "title": "ജ്വലിക്കുന്ന മനസ്സുകൾ",
    "author": "എപിജെ അബ്ദുൽ കലാം ",
    "category": "STUDY"
  },
  {
    "serialNo": 661,
    "bookNo": "ST-3/8",
    "title": "പ്രവർത്തകന്റെ പണിപ്പുര",
    "author": "മാളിയേക്കൽ  സുലൈമാൻ സഖാഫി ",
    "category": "STUDY"
  },
  {
    "serialNo": 662,
    "bookNo": "ST-4/215",
    "title": "സുന്നത് ജമാഅത്",
    "author": "മാളിയേക്കൽ  സുലൈമാൻ സഖാഫി ",
    "category": "STUDY"
  },
  {
    "serialNo": 663,
    "bookNo": "ST-5/236",
    "title": "മുസ്ലിം നവോഥാനം ചില കേരളീയ ചിത്രങ്ങൾ",
    "author": "എ പി അഹമദ്",
    "category": "STUDY"
  },
  {
    "serialNo": 664,
    "bookNo": "ST-6/127",
    "title": "വാർത്തകൾക്കപ്പുറം ",
    "author": "കാസിം ഇരിക്കൂർ ",
    "category": "STUDY"
  },
  {
    "serialNo": 665,
    "bookNo": "ST-7/389",
    "title": "നിസ്കാര പാഠശാല ",
    "author": "അബൂബക്കർ ശർവാനി ",
    "category": "STUDY"
  },
  {
    "serialNo": 666,
    "bookNo": "ST-8/129",
    "title": "ഇസ്ലാം വായന ഭീതിയും നീതിയും",
    "author": "രാജീവ് ശങ്കരൻ",
    "category": "STUDY"
  },
  {
    "serialNo": 667,
    "bookNo": "ST-9/132",
    "title": "ഗാഡ്ഗിൽ റിപ്പോർട്ടും കേരള വികസനവും",
    "author": "ടി.പി. കുഞ്ഞിക്കണ്ണൻ ",
    "category": "STUDY"
  },
  {
    "serialNo": 668,
    "bookNo": "ST-10/111",
    "title": "വചനങ്ങൾ",
    "author": "എപിജെ അബ്ദുൽ കലാം",
    "category": "STUDY"
  },
  {
    "serialNo": 669,
    "bookNo": "ST-11/5",
    "title": "ഇസ്‌ലാം ബഹുസ്വരത ",
    "author": "ഡോ. ഉമുറുൽ ഫാറൂഖ് സഖാഫി ",
    "category": "STUDY"
  },
  {
    "serialNo": 670,
    "bookNo": "ST-12/124",
    "title": "മാധ്യമങ്ങളുടെ മുസ്ലിമും മുസ്ലിംകളുടെ മാധ്യമങ്ങളും ",
    "author": "നുഐമാൻ ",
    "category": "STUDY"
  },
  {
    "serialNo": 671,
    "bookNo": "ST-13/142",
    "title": "ജനാധിപത്യവും സിവിൽ സമൂഹവും ",
    "author": "കെ. വേണു",
    "category": "STUDY"
  },
  {
    "serialNo": 672,
    "bookNo": "ST-14/242",
    "title": "പ്രതിരോധങ്ങൾക്ക് ഒരു ആമുഖം",
    "author": "കെ കെ ജോഷി",
    "category": "STUDY"
  },
  {
    "serialNo": 673,
    "bookNo": "ST-15/9",
    "title": "രിസാല - ഒരു യാഥാസ്ഥിതിക മുസ്ലിം \nപ്രസിദ്ധീകരണത്തിന്റെ അകം കഥകൾ",
    "author": "ഒരു കൂട്ടം ലേഖകർ",
    "category": "STUDY"
  },
  {
    "serialNo": 674,
    "bookNo": "ST-16/646",
    "title": "അറബി ഭാഷ കേരളത്തിൽ",
    "author": "എ ആർ കൊടിയത്തൂർ",
    "category": "STUDY"
  },
  {
    "serialNo": 675,
    "bookNo": "ST-17/133",
    "title": "പഠിക്കാം ഡച്ച് പാഠങ്ങൾ/ പ്രളയം/ \nപ്രതിരോധം / പുനർനിർമാണം ",
    "author": "വേണു രാജാമണി മഹേഷ എൻ എം ",
    "category": "STUDY"
  },
  {
    "serialNo": 676,
    "bookNo": "ST-18/134",
    "title": "കേരളം സുസ്ഥിര വികസനത്തിന് ഒരു രൂപരേഖ",
    "author": "ടി.പി കുഞ്ഞിക്കണ്ണൻ",
    "category": "STUDY"
  },
  {
    "serialNo": 677,
    "bookNo": "ST-19/216",
    "title": "വർത്തമാന കാല വർത്തമാനങ്ങൾ",
    "author": "ആനന്ദ് / എം എൻ കാരശ്ശേരി",
    "category": "STUDY"
  },
  {
    "serialNo": 678,
    "bookNo": "ST-20/217",
    "title": "പോസ്റ്റ് ട്രൂത്ത് ടെലിവിഷൻ",
    "author": "ടി കെ സന്തോഷ്കുമാർ",
    "category": "STUDY"
  },
  {
    "serialNo": 679,
    "bookNo": "ST-21/113",
    "title": "മലയാള ചെറുകഥയും സ്വത്വാവിഷ്കാരവും ",
    "author": "ടി മൻസൂറലി ",
    "category": "STUDY"
  },
  {
    "serialNo": 680,
    "bookNo": "ST-22/117",
    "title": "വ്യക്തി നിയമങ്ങളും ഏകീകൃത സിവിൽ കോഡും ",
    "author": "കാസിം ഇരിക്കൂർ ",
    "category": "STUDY"
  },
  {
    "serialNo": 681,
    "bookNo": "ST-23/116",
    "title": "പ്രകൃതിയുടെ നിലവിളികൾ",
    "author": "സി ആർ നീലകണ്ഠൻ ",
    "category": "STUDY"
  },
  {
    "serialNo": 682,
    "bookNo": "ST-24/118",
    "title": "തമസ്കിരണങ്ങൾ  മാർക്സും പ്രതി-പ്രകാശദർശനവും ",
    "author": "അൻവർ ഹനീഫ",
    "category": "STUDY"
  },
  {
    "serialNo": 683,
    "bookNo": "ST-25/382",
    "title": "സമാ ഏ ബിസ്മിൽ - ഖവാലിയുടെ ഉൾലോകങ്ങൾ ",
    "author": "എം നൗഷാദ് ",
    "category": "STUDY"
  },
  {
    "serialNo": 684,
    "bookNo": "ST-26/128",
    "title": "മറു ചോദ്യം മറുത്തൊരു ജീവിതം",
    "author": "ഒരു കൂട്ടം ലേഖകർ",
    "category": "STUDY"
  },
  {
    "serialNo": 685,
    "bookNo": "ST-27/121",
    "title": "യുവത്വം കൊതിക്കുന്ന ഇന്ത്യ",
    "author": "എപിജെ അബ്ദുൽ കലാം",
    "category": "STUDY"
  },
  {
    "serialNo": 686,
    "bookNo": "ST-28/122",
    "title": "പ്രവർത്തകന്റെ പണിപ്പുര",
    "author": "മാളിയേക്കൽ  സുലൈമാൻ സഖാഫി ",
    "category": "STUDY"
  },
  {
    "serialNo": 687,
    "bookNo": "ST-29/123",
    "title": "ജെറുസലേം കുടിയിറക്കപ്പെട്ടവന്റെ മേൽവിലാസം",
    "author": "ഡോ ആങ് സ്വീചായ്/ അബ്ദുല്ല മണിമ ",
    "category": "STUDY"
  },
  {
    "serialNo": 688,
    "bookNo": "ST-30/125",
    "title": "മുസ്ലിം മാധ്യമനുഭവങ്ങൾ",
    "author": "ഒരു സംഘം ലേഖകർ ",
    "category": "STUDY"
  },
  {
    "serialNo": 689,
    "bookNo": "ST-31/22",
    "title": "പ്രണയം, ലഹരി, ജിഹാദ്, ഇസ് ലാം ഭീതി",
    "author": "മുഹമ്മദലി കിനാലൂർ",
    "category": "STUDY"
  },
  {
    "serialNo": 690,
    "bookNo": "ST-32/275",
    "title": "Annihilation of caste",
    "author": "Dr.Br Ambedkar",
    "category": "STUDY"
  },
  {
    "serialNo": 691,
    "bookNo": "ST-33/17",
    "title": "മനുഷ്യാ ഒന്നോർമിക്കൂ..!",
    "author": "പി എ കെ മുഴാപാല",
    "category": "STUDY"
  },
  {
    "serialNo": 692,
    "bookNo": "ST-34/2",
    "title": "നോമ്പിന്റെ കാമ്പ്",
    "author": "ഡോ.ഫൈസൽ അഹ്‌സനി",
    "category": "STUDY"
  },
  {
    "serialNo": 693,
    "bookNo": "ST-35/126",
    "title": "വാർത്തകളുടെ കാണാപ്പുറങ്ങൾ",
    "author": "കാസിം ഇരിക്കൂർ",
    "category": "STUDY"
  },
  {
    "serialNo": 694,
    "bookNo": "ST-36/93",
    "title": "മയ്യിത്ത് പരിപാലനകർമങ്ങൾ ",
    "author": "ഡോ. എം അബ്ദുൽ അസീസ് ഫൈസി ",
    "category": "STUDY"
  },
  {
    "serialNo": 695,
    "bookNo": "ST-37/500",
    "title": "മലബാർ ദേശീയതയുടെ  ഇടപാടുകൾ ",
    "author": "എം ടി അൻസാരി ",
    "category": "STUDY"
  },
  {
    "serialNo": 696,
    "bookNo": "ST-38/101",
    "title": "കേരള മുസ്ലിം നവോത്ഥാനം",
    "author": "ഒരു സംഘം ലേഖകർ",
    "category": "STUDY"
  },
  {
    "serialNo": 697,
    "bookNo": "ST-39/119",
    "title": "പ്രധാനമന്ത്രി : വൈരുദ്ധ്യങ്ങളുടെ നായകൻ",
    "author": "ശശി തരൂർ ",
    "category": "STUDY"
  },
  {
    "serialNo": 698,
    "bookNo": "ST-40/94",
    "title": "മയ്യിത്ത് പരിപാലനകർമങ്ങൾ ",
    "author": "ഡോ. എം അബ്ദുൽ അസീസ് ഫൈസി ",
    "category": "STUDY"
  },
  {
    "serialNo": 699,
    "bookNo": "ST-41/242",
    "title": "THE EPIC THAT IS ENGLISH",
    "author": "പ്രൊഫ.വി. സുകുമാരൻ",
    "category": "STUDY"
  },
  {
    "serialNo": 700,
    "bookNo": "ST-42/699",
    "title": "പഠിക്കാൻ പഠിക്കാം",
    "author": "മുഹമ്മദ് പാറന്നൂർ",
    "category": "STUDY"
  },
  {
    "serialNo": 701,
    "bookNo": "ST-43/569",
    "title": "കുട്ടികളുടെ വ്യക്തിത്വം രൂപീകരിക്കുന്നതിൽ \nമാതാപിതാക്കളുടെ പങ്ക്",
    "author": "കെ സി ശൈജൻ",
    "category": "STUDY"
  },
  {
    "serialNo": 702,
    "bookNo": "ST-44/647",
    "title": "ഉർദു ടെക്നിക്ക്",
    "author": "ബസീർ പുല്ലരി കോട്",
    "category": "STUDY"
  },
  {
    "serialNo": 703,
    "bookNo": "ST-45/847",
    "title": "നീതിയുടെ വിതാനങ്ങൾ ",
    "author": "",
    "category": "STUDY"
  },
  {
    "serialNo": 704,
    "bookNo": "ST-46/848",
    "title": "VAQAF ഭേദഗതി ബില് 2024 ",
    "author": "",
    "category": "STUDY"
  },
  {
    "serialNo": 705,
    "bookNo": "ST-47/842",
    "title": "വിഎസ് ജനപക്ഷം",
    "author": "",
    "category": "STUDY"
  },
  {
    "serialNo": 706,
    "bookNo": "ST-48/825",
    "title": "പാലസ്തീൻ ഇരകളുടെ ഇരകൾ",
    "author": "",
    "category": "STUDY"
  },
  {
    "serialNo": 707,
    "bookNo": "ST-49/845",
    "title": "സ്മൃതി പർവത്തിലൂടെ",
    "author": "",
    "category": "STUDY"
  },
  {
    "serialNo": 708,
    "bookNo": "SHE 1/534",
    "title": "THE FUTURE WE CHOOSE",
    "author": "CHRISTIANA FIGUERES",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 709,
    "bookNo": "SHE 2\\485",
    "title": "THE ROARING LAMBS",
    "author": "SREEDHAR BEVARA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 710,
    "bookNo": "SHE 3\\486",
    "title": "THE ROARING LAMBS",
    "author": "SHREEDHAR BEVARA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 711,
    "bookNo": "SHE 4 \\487",
    "title": "BRAVE NOT PERFECT",
    "author": "RESHMA SANJANI",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 712,
    "bookNo": "SHE 5\\488",
    "title": "THE POWER OF YOUR SUBCONCIOUS MIND",
    "author": "DR.JOSEPH MURPHY",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 713,
    "bookNo": "SHE 6\\489",
    "title": "THE MASTERY MANUAL",
    "author": "ROBIN SHARMA ",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 714,
    "bookNo": "SHE 7\\490",
    "title": "THE 5AM CLUB OWN YOUR MORNING...",
    "author": "ROBIN SHARMA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 715,
    "bookNo": "SHE 8/533",
    "title": "THE POWER OF YOUR SUBCONSCIOUS MIND",
    "author": "JOSEPH MURPHY",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 716,
    "bookNo": "SHE 9\\492",
    "title": "MINDSET",
    "author": "DR.CAROL S.DWECK",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 717,
    "bookNo": "SHE 10\\493",
    "title": "THE SUBTLE ART OF NOT GIVING A FUCK",
    "author": "MARK MANSON",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 718,
    "bookNo": "SHE 11\\494",
    "title": "EVERYTHING IS FUCKED",
    "author": "MARK MANSON",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 719,
    "bookNo": "SHE 12\\495",
    "title": "YOUNG MENTAL HEALTH",
    "author": "AMRITA TRIPATHI, MEERA HARAN ALVA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 720,
    "bookNo": "SHE 13\\496",
    "title": " A HICHER LOYALTY",
    "author": "JAMES COMEY",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 721,
    "bookNo": "SHE-14/497",
    "title": "NO NONSENSE INSPIRE YOUR STAFF",
    "author": "JERRY- R-WILSON",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 722,
    "bookNo": "SHE- 15/498",
    "title": "NO NONSENSE INSPIRE YOUR STAFF",
    "author": "JERRY - R - WILSON",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 723,
    "bookNo": "SHE -16/499",
    "title": "EDGE LEADERSHIP SECRETS FROM FOOTBALLS TOP \nTHINKERS L",
    "author": "BEN LYTTLETON",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 724,
    "bookNo": "SHE 17/532",
    "title": "A BORING WAY TO GET RICH",
    "author": "DHIRENDRA KUMAR",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 725,
    "bookNo": "SHE-18/501",
    "title": "EMOTIONAL INTELLIGENCE",
    "author": "DANIEL GOLEMAN",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 726,
    "bookNo": "SHE-19/502",
    "title": "AN APPEAL TO THE WORLD",
    "author": "DALAILAMA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 727,
    "bookNo": "SHE -20/ 503",
    "title": "THE POWER OF HABIT",
    "author": "CHARLES DUHIGG",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 728,
    "bookNo": "SHE-21/504",
    "title": "THINK LIKE A MONK ",
    "author": "JAY  SHETTY",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 729,
    "bookNo": "SHE-22/505",
    "title": "UNCONSIOUS BIAS",
    "author": "PAMELA FULLER , MARK MURFI",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 730,
    "bookNo": "SHE-23/506",
    "title": "UNCONSIOUS BIAS ",
    "author": "PAMELA FULLER , MARK MURPHY",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 731,
    "bookNo": "SHE-24/507",
    "title": "12 RULES FOR LIFE ",
    "author": "JORDAN B. PETERSON",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 732,
    "bookNo": "SHE-25/508",
    "title": "RICH DAD POOR DAD",
    "author": "ROBERT T. KIYOSAKI",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 733,
    "bookNo": "SHE - 26/509",
    "title": "GOLD STANDARD",
    "author": "NAPOLEAN HILLS",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 734,
    "bookNo": "SHE -27/510",
    "title": "THINK AND GROW RICH",
    "author": "NAPOLEAN HILL",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 735,
    "bookNo": "SHE -28/511",
    "title": "LIFE LESSONS FROM THE EAST END",
    "author": "DANNY DYER",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 736,
    "bookNo": "SHE-29/512",
    "title": "WORD POWER MADE EASY ",
    "author": "NORMAN LEWIS ",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 737,
    "bookNo": "SHE 30/530",
    "title": "ROAD TO SUCCESS",
    "author": "FAIZAL AHSANI,ULIYIL",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 738,
    "bookNo": "SHE 31/529",
    "title": "YOU CAN WIN",
    "author": "SHIV KHERA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 739,
    "bookNo": "SHE-32/525",
    "title": "RESILIENCE",
    "author": "HARDWARD BUISNESS",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 740,
    "bookNo": "SHE-33/633",
    "title": "FOCUS",
    "author": "SERIES",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 741,
    "bookNo": "SHE-34/634",
    "title": "MINDFUL LISTENING",
    "author": "SERIES",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 742,
    "bookNo": "SHE-35/517",
    "title": "PERMISSION TO DREAM ",
    "author": "CHRIS GARDENER AND MIM \nEICHLER RIVAS ",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 743,
    "bookNo": "SHE-36/519",
    "title": "THE CHILDREN OF TOMORROW ",
    "author": "OM SWAMI",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 744,
    "bookNo": "SHE- 37/522",
    "title": "REWORK",
    "author": "JASON FRIED AND DAVID HEINMIER \nHANSSON",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 745,
    "bookNo": "SHE-38/516",
    "title": "52 RED PILLS",
    "author": "",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 746,
    "bookNo": "SHE-39/177",
    "title": "THINKING FAST  AND SLOW ",
    "author": "",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 747,
    "bookNo": "SHE-40/524",
    "title": "DAILY INSPIRARTION ",
    "author": "ROBIN SHARMA ",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 748,
    "bookNo": "SHE-41/731",
    "title": "THE 5 A M CLUB",
    "author": "ROBIN SHARMA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 749,
    "bookNo": "SHE-42/732",
    "title": "THE 5 A M CLUB",
    "author": "ROBIN SHARMA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 750,
    "bookNo": "SHE-43/733",
    "title": "IKIGAI",
    "author": "HECTOR GARCIA AND FRANCESC MIRALLES",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 751,
    "bookNo": "SHE-44/734",
    "title": "IKIGAI",
    "author": "HECTOR GARCIA AND FRANCESC MIRALLES",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 752,
    "bookNo": "SHE-45/735",
    "title": "WHO WILL CRY WHEN YOU DIE?",
    "author": "ROBIN SHARMA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 753,
    "bookNo": "SHE-46/736",
    "title": "WHO WILL CRY WHEN YOU DIE?",
    "author": "ROBIN SHARMA",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 754,
    "bookNo": "SHE-47/740",
    "title": "RICH DAD POOR DAD",
    "author": "ROBERT T KIYOSAKI",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 755,
    "bookNo": "SHE-48/741",
    "title": "RICH DAD POOR DAD",
    "author": "ROBERT T KIYOSAKI",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 756,
    "bookNo": "SHE-49/753",
    "title": "ATTITUDE IS EVERYTHING",
    "author": "JEFF KELLER",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 757,
    "bookNo": "SHE-50/762",
    "title": "THINK AND GROW RICH",
    "author": "NAPOLEAN HILL",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 758,
    "bookNo": "SHE-51/768",
    "title": "THE POWER OF YOUR SUBCONSCIOUS MIND",
    "author": "DR . JOSEPH MURPHY",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 759,
    "bookNo": "SHE-52/805",
    "title": "THE LEADER IN YOU",
    "author": "DALE CARNGIE",
    "category": "Self Help (English)"
  },
  {
    "serialNo": 760,
    "bookNo": "SH-1/271",
    "title": "വിജയത്തിലേക്ക് ഒരു യാത്ര ",
    "author": "ബി എസ് വാരിയർ ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 761,
    "bookNo": "SH-2/272",
    "title": "വിജയത്തിലേക്ക് ",
    "author": "കെ പി കേശവമേനോൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 762,
    "bookNo": "SH-3/273",
    "title": "21-ാം നൂറ്റാണ്ടിലേക്ക് 21 പാഠങ്ങൾ ",
    "author": "യുവാൽ നോവ ഹരാരി / ഡെന്നി തോമസ് ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 763,
    "bookNo": "SH-4/274",
    "title": "പൊതുവിജ്ഞാനം - തെറ്റും ശരിയും ",
    "author": "ആർ സി സുരേഷ് കുമാർ ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 764,
    "bookNo": "SH-5/643",
    "title": "ധ്യാനങ്ങൾ",
    "author": "ജെ  കൃഷ്ണമൂർത്തി",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 765,
    "bookNo": "SH-6/276",
    "title": "ദൈവത്തിന്റെ ചാരന്മാർ",
    "author": "ജോസഫ് അന്നംകുട്ടി ജോസ്",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 766,
    "bookNo": "SH-7/277",
    "title": "അറിയാത്തതും അറിയേണ്ടതും",
    "author": "ഷെരീഫ് നെടുമങ്ങാട് ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 767,
    "bookNo": "SH-8/278",
    "title": "വിജയപദം -കർമ്മയോഗികളും വിജയവഴികളും",
    "author": "ദേബാശിഷ് ചാറ്റർജി/ മധുസൂതനൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 768,
    "bookNo": "SH-9/279",
    "title": "വിജയത്തിന്റെ പടവുകൾ ",
    "author": "ബി.എസ്. വാരിയർ ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 769,
    "bookNo": "SH-10/280",
    "title": "കുസൃതിയില്ലാത്ത കുട്ടികൾ - ഭാഗം ഒന്ന് ",
    "author": "അഡ്വാ. മുഈനുദ്ദീൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 770,
    "bookNo": "SH-11/281",
    "title": "പാഠം ഒന്ന് ആത്മ വിശ്വാസം",
    "author": "എം പി ലിപിൻ രാജ്",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 771,
    "bookNo": "SH-12/282",
    "title": "പാഠം ഒന്ന് ആത്മ വിശ്വാസം",
    "author": "എം പി ലിപിൻ രാജ്",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 772,
    "bookNo": "SH-13/283",
    "title": "പാഠം ഒന്ന് ആത്മ വിശ്വാസം",
    "author": "എം പി ലിപിൻ രാജ്",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 773,
    "bookNo": "SH-14/284",
    "title": "വിജയ പഥം - കർമ യോഗികളുടെ വിജയ വഴികളും",
    "author": "ദേബാശിഷ് ചാറ്റർജി / മധുസൂദൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 774,
    "bookNo": "SH-15/642",
    "title": "ഓർമ്മശക്തി വർധിപ്പിക്കാം",
    "author": "പി കെ എ റഷീദ് ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 775,
    "bookNo": "SH-16/310",
    "title": "ഇരുപത്തി ഒന്നാം നൂറ്റാണ്ടിലേക്ക് 21 പാഠങ്ങൾ ",
    "author": "യുവാൽ നോവ ഹാരാരി ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 776,
    "bookNo": "SH-17/287",
    "title": "ലളിത ജീവിതം ",
    "author": "കെ. ജയകുമാർ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 777,
    "bookNo": "SH-18/288",
    "title": "എന്നും യുവത്വം",
    "author": "പ്രൊഫ. പി എ വർഗീസ് ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 778,
    "bookNo": "SH-19/289",
    "title": "ഏകാഗ്രതയും ധ്യാനവും ",
    "author": "സ്വാമി പരമാനന്ദ് ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 779,
    "bookNo": "SH-20/290",
    "title": "ബി - പോസിറ്റീവ് ",
    "author": "ജിജോ സിറിയക് ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 780,
    "bookNo": "SH-21/291",
    "title": "ശ്രീ ധന്യയുടെ വിജയ യാത്രകൾ",
    "author": "ടി വി രവീന്ദ്രൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 781,
    "bookNo": "SH-22/292",
    "title": "കൗമാരവും ജീവിതവിജയവും",
    "author": "സെബിൻ എസ് കൊട്ടാരം, ജോബിൻ എസ് കൊട്ടാരം",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 782,
    "bookNo": "SH-23/293",
    "title": "വിജയഗാഥ: വളരുന്ന മാനേജുമാർക്ക് ഒരു കൈ പുസ്തകം",
    "author": "കരിമ്പുഴ രാമൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 783,
    "bookNo": "SH-24/294",
    "title": "മന:സമാധനം ഉണ്ടാവാൻ",
    "author": "ഡോ എസ്- ശാന്തകുമാർ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 784,
    "bookNo": "SH-25/295",
    "title": "റിച്ച് ഡാഡ് പുവർ ഡാഡ്",
    "author": "റോബർട്ട് റ്റി. കിയോസാകി / കെ.കെ ജയകുമാർ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 785,
    "bookNo": "SH-26 /296",
    "title": "ഈ നിമിഷത്തിൽ ജീവിക്കൂ",
    "author": "എക് ഹാർട് ടൊളെ /അനിത ജയനാഥ്",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 786,
    "bookNo": "SH-27/297",
    "title": "നിരവധി ജന്മങ്ങൾ, അനവധി ഗുരുക്കന്മാർ",
    "author": "ഡോ. ബ്രിയാൻ എൽവീസ് /രാധാകൃഷ്ണൻ \nപണിക്കർ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 787,
    "bookNo": "SH-28/298",
    "title": "വിജയം സുനിശ്ചിതം",
    "author": "റോബിൻ. എസ്. ശർമ്മ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 788,
    "bookNo": "SH-29/299",
    "title": "365 ദൈനംദിന പ്രതിജ്ഞകൾ:സമ്പുഷ്ടമായ\n ജീവിതവിജയത്തിന്",
    "author": "ഡോ: യാൻയാഗർ / ശ്രീലത .എസ്",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 789,
    "bookNo": "SH30/286",
    "title": "പ്രഭാത ദീപം",
    "author": "കെ. പി കേശവമേനോൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 790,
    "bookNo": "SH-31/308",
    "title": "സംഘടന നേതൃത്വം",
    "author": "മജീദ് അരിയല്ലൂർ ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 791,
    "bookNo": "SH-32/302",
    "title": "ഹൌ ടു വിൻ ഫ്രണ്ട്സ് ആൻഡ് ഇൻഫ്ലുവൻസ് പീപ്പിൾ ",
    "author": "ഡേൽകാർണഗി/ജയ്സൺ കൊച്ചുവീടൻ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 792,
    "bookNo": "SH-33/303",
    "title": "അറ്റോമിക് ഹാബിറ്റസ് ചെറിയ മാറ്റങ്ങൾ \nശ്രദ്ധേയമായ ഫലങ്ങൾ ",
    "author": "ജെംലിംസ് ക്ലിയർ പ്രഭാസക്കറിയ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 793,
    "bookNo": "SH-34/304",
    "title": "സെക്കുലർ പോലീസ്",
    "author": "പിജി ജാതവേദൻ നമ്പൂതിരിനമ്പൂതിരി",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 794,
    "bookNo": "SH-35/112",
    "title": "വിടരേണ്ട പൂമൊട്ടുകൾ",
    "author": "APJ Abdul Kalam/അരുൺ കെ തിവാരി",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 795,
    "bookNo": "SH-36/306",
    "title": "നിങ്ങൾക്കും  വിജയം നേടാം",
    "author": "മാർട്ടിൻ പല്ലപിള്ളി ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 796,
    "bookNo": "SH-37/307",
    "title": "ജീവിത വിജയത്തിന് 100 കഥകൾ",
    "author": "ബോബി സി.മാത്യു",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 797,
    "bookNo": "SH-38/597",
    "title": "വിജയം സുനിശ്ചിതം",
    "author": "റോബിൻ. എസ്. ശർമ്മ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 798,
    "bookNo": "SH-39/6",
    "title": "അയ്യുഹൽ വലദ്",
    "author": "ഇമാം ഗസ്സാലി",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 799,
    "bookNo": "SH-40/599",
    "title": "പ്രഥമ ലക്ഷ്യ കണ്ടത്തുക",
    "author": "സ്റ്റീഫൻ ആർ.കോവെ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 800,
    "bookNo": "SH-41/596",
    "title": "ആത്മ വിശ്വാസം",
    "author": "എം പി ലിപിൻരാജ്",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 801,
    "bookNo": "SH-42/742",
    "title": "റിച് ഡാഡ് പുവർ ഡാഡ്",
    "author": "റോബർട്ട് റ്റി കിയോസാകി",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 802,
    "bookNo": "SH-43/763",
    "title": "THE MONK WHO SOLD HIS FERRARI",
    "author": "റോബിൻ എസ ശർമ്മ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 803,
    "bookNo": "SH-44/772",
    "title": "പണത്തിന്റെ മനഃശാസ്ത്രം",
    "author": "മോർഗൻ ഹൊസെയിൽ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 804,
    "bookNo": "SH-45/798",
    "title": "90 ഡെയ്സ് ടു ലൈഫ്",
    "author": "റൂബിൾ ചാണ്ടി ",
    "category": "Self Help (Malayalam)(SH)"
  },
  {
    "serialNo": 805,
    "bookNo": "SP-1/137",
    "title": "ശരി തിരൂരിന്റെ പ്രഭാഷണങ്ങൾ ",
    "author": "ശശി തരൂർ / സിസിലി",
    "category": "SPEECH"
  },
  {
    "serialNo": 806,
    "bookNo": "SP-2/491",
    "title": "വഴിവെളിച്ചങ്ങൾ",
    "author": "APJ  ABDUL KALAM / ARUN K THIVARI ",
    "category": "SPEECH"
  },
  {
    "serialNo": 807,
    "bookNo": "SP-3/52",
    "title": "ചെവിയോർക്കുക ! അന്തിമകാഹളം !!",
    "author": "ബഷീർ",
    "category": "SPEECH"
  },
  {
    "serialNo": 808,
    "bookNo": "SP-4/65",
    "title": "102 പ്രസംഗങ്ങൾ",
    "author": "തുളസി കൊട്ടുക്കൽ",
    "category": "SPEECH"
  },
  {
    "serialNo": 809,
    "bookNo": "SP-5/513",
    "title": "മലയാളത്തിന്റെ ജ്ഞാനപീഠ പ്രഭാഷണങ്ങൾ ",
    "author": "ഒരു സംഘം ലേഖകർ",
    "category": "SPEECH"
  },
  {
    "serialNo": 810,
    "bookNo": "T-1/359",
    "title": "ഇന്ത്യൻ യാത്രകൾ",
    "author": "ശ്രീകാന്ത് കോട്ടക്കൽ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 811,
    "bookNo": "T-2/360",
    "title": "ബോസ് ഫറസിന്റെ ഭാഗ്യം ",
    "author": "ഡോക്ടർ എ പി അബ്ദുൽ ഹക്കീം",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 812,
    "bookNo": "T-3/361",
    "title": "അനുരാഗിയുടെ തീർത്ഥാടന വഴികൾ",
    "author": "ഡോ. ഫൈസൽ അഹ്സനി രണ്ടത്താണി",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 813,
    "bookNo": "T-4/362",
    "title": "ദോഹ ഡയറി",
    "author": "ഇ കെ. നായനാർ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 814,
    "bookNo": "T-5/363",
    "title": "യാത്ര-ഇന്ത്യൻ ചരിത്ര സ്മാരകങ്ങളിലൂടെ",
    "author": "കെ വിശ്വനാഥ ്",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 815,
    "bookNo": "T-6/364",
    "title": "ഇന്ത്യ എൻറെ പ്രണയ വിസ്മയം",
    "author": "ഗോപിനാഥ് മുതുകാട്",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 816,
    "bookNo": "T-7/365",
    "title": "ഹിമാലയത്തിൽ ഒരു അവധൂതൻ",
    "author": "പോൾ ബ്രണ്ടൻ ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 817,
    "bookNo": "T-8/366",
    "title": "വനയാത്ര ",
    "author": "ആർ വിനോദ് കുമാർ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 818,
    "bookNo": "T-9/367",
    "title": "മരുമരങ്ങൾ",
    "author": "വി. മുസഫർ അഹമ്മദ് ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 819,
    "bookNo": "T-10/368",
    "title": "ബങ്കറിന് അരികിലെ  ബുദ്ധൻ ",
    "author": "വി. മുസഫർ അഹമ്മദ് ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 820,
    "bookNo": "T-11/369",
    "title": "ഹിമാലയ പ്രത്യക്ഷങ്ങൾ",
    "author": "ആഷാ മേനോൻ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 821,
    "bookNo": "T-12/370",
    "title": "പാറക്കല്ലോ ഏതൻസ് ",
    "author": "സന്തോഷ് ഏച്ചിക്കാനം",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 822,
    "bookNo": "T-13/371",
    "title": "ഭൂട്ടാൻ വിശേഷങ്ങൾ",
    "author": "എം ആർ രേണകുമാർ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 823,
    "bookNo": "T-14/372",
    "title": "കൂ കൂ കൂ കൂ തീവണ്ടി ",
    "author": "അനിത നായർ ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 824,
    "bookNo": "T-15/373",
    "title": "ബാവുൽ -ജീവിതവും സംഗീതവും ",
    "author": "മിംലുമ്പൻ ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 825,
    "bookNo": "T-16/374",
    "title": "ഹൈമവത ഭൂവിൽ ",
    "author": "എം. പി വീരേന്ദ്രകുമാർ ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 826,
    "bookNo": "T-17/375",
    "title": "ദേശദനം ",
    "author": "ബൈജു എൻ നായർ ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 827,
    "bookNo": "T-18/376",
    "title": "സഞ്ചാരം - 10 രാജ്യങ്ങളിലേക്കുള്ള ബജറ്റ് യാത്രകൾ ",
    "author": "സന്തോഷ്‌ ജോർജ് കുളങ്ങര ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 828,
    "bookNo": "T-19/377",
    "title": "ശ്രീഹരിക്കോട്ടയിലേക്ക് വീണ്ടും ",
    "author": "കണ്ണോത് കൃഷ്ണൻ ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 829,
    "bookNo": "T-20/378",
    "title": "ബുഖാര, സുനാനി ഒരു മധ്യേഷ്യൻ കഥ ",
    "author": "അഡ്വ. മുഹമ്മദ്‌ ഷംവീൽ നൂറാനി ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 830,
    "bookNo": "T-21/379",
    "title": "ഗ്രാമപാഥകൾ - ഇന്ത്യൻ യാത്രകളുടെ പുസ്തകം ",
    "author": "പി. സുരേന്ദ്രൻ ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 831,
    "bookNo": "T-22/158",
    "title": "ഹാജി",
    "author": "മൈക്കിൾ വോൾഫ് ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 832,
    "bookNo": "T-23/24",
    "title": "മക്കയിലേക്ക് ഉള്ള പാത",
    "author": "മുഹമ്മദ്‌ അസദ്  / എം.എൻ.കാർശ്ശേരി",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 833,
    "bookNo": "T-24/617",
    "title": "TIBET'S SECRET MOUNTAIN",
    "author": "CHRIS BONINGTON",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 834,
    "bookNo": "T-25/618",
    "title": "INDIA MY LOVE ",
    "author": "DOMMINIQUE LAPIERRE",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 835,
    "bookNo": "T-26/619",
    "title": "DESI DELICACIES",
    "author": "CLAIRE CHAMBERS",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 836,
    "bookNo": "T-27/622",
    "title": "എൻറെ പശ്ചിമേഷന്‍ യാത്ര",
    "author": "നജഫ് പാവണ്ടൂർ",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 837,
    "bookNo": "T-28/57",
    "title": "മക്കയിലേക്ക് അനേകം വഴികൾ",
    "author": "എ കെ അബ്ദുൽ മജീദ്",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 838,
    "bookNo": "T-29/232",
    "title": "കാപ്പിരികളുടെ നാട്ടിൽ",
    "author": "എസ് കെ പൊറ്റക്കാട്ട്",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 839,
    "bookNo": "T-30/758",
    "title": "അഫ്‌ഗാനിസ്താൻ",
    "author": "ജോമോൻ ജോസഫ്",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 840,
    "bookNo": "T-31/811",
    "title": "കൂബക്കൂ . CO",
    "author": "HANNA MEHTHAR",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 841,
    "bookNo": "T-32/850",
    "title": "ഹിമാലയ സാമ്രാജ്യത്തിൽ ",
    "author": "",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 842,
    "bookNo": "T-33/851",
    "title": "സോവിയറ്റ്‌ ഡയറി ",
    "author": "",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 843,
    "bookNo": "T-34/854",
    "title": "സോവിയറ്റ്‌ ഡയറി  PART 2",
    "author": "",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 844,
    "bookNo": "T-35/853",
    "title": "നൈൽ ഡയറി ",
    "author": "",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 845,
    "bookNo": "T-36/852",
    "title": "മലയാനാടുകളിൽ  ",
    "author": "",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 846,
    "bookNo": "T-37/836",
    "title": "ഡൽഹി ഡയറി",
    "author": "",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 847,
    "bookNo": "T-38/833",
    "title": "വിശുദ്ധ പാപങ്ങളുടെ ഇന്ത്യ",
    "author": "",
    "category": "Travelogue(T)"
  },
  {
    "serialNo": 848,
    "bookNo": "TR-1/644",
    "title": "THE HOLY QURAN ENGLISH TRANSLATION ",
    "author": "IFTA",
    "category": "TRANSLTION"
  },
  {
    "serialNo": 849,
    "bookNo": "TR-2/645",
    "title": "THE HOLY QURAN ENGLISH TRANSALATION",
    "author": "IFTA",
    "category": "TRANSLTION"
  },
  {
    "serialNo": 850,
    "bookNo": "YR-1/684",
    "title": "MATHRUBHUMI YEARBOOK 2019",
    "author": "MATHRUBHUMI",
    "category": "YEAR BOOK"
  },
  {
    "serialNo": 851,
    "bookNo": "YR-2/698",
    "title": "Manorama Yearbook 2023",
    "author": "Manorama",
    "category": "YEAR BOOK"
  },
  {
    "serialNo": 852,
    "bookNo": "YR-3/404",
    "title": "Manorama Yearbook 2023",
    "author": "Manorama",
    "category": "YEAR BOOK"
  },
  {
    "serialNo": 853,
    "bookNo": "1",
    "title": "R-60/697",
    "author": "UPSC IAS/IPS Prelims",
    "category": "MISSING"
  },
  {
    "serialNo": 854,
    "bookNo": "2",
    "title": "R-30/667",
    "author": "ENVIORNMENT",
    "category": "MISSING"
  },
  {
    "serialNo": 855,
    "bookNo": "3",
    "title": "ABE-5/571",
    "author": "LIFE WITHOUT LIMITS",
    "category": "MISSING"
  },
  {
    "serialNo": 856,
    "bookNo": "4",
    "title": "ABE-10/576",
    "author": "CAN'T HURT ME",
    "category": "MISSING"
  },
  {
    "serialNo": 857,
    "bookNo": "5",
    "title": "ABE-15/581",
    "author": "SHOE DOG",
    "category": "MISSING"
  },
  {
    "serialNo": 858,
    "bookNo": "6",
    "title": "ABE-18/584",
    "author": "PLAYING IT MY WAY",
    "category": "MISSING"
  },
  {
    "serialNo": 859,
    "bookNo": "7",
    "title": "SH-5/275",
    "author": "പി.എ.സി. ക്യാപ്സ്യൂൾ",
    "category": "MISSING"
  },
  {
    "serialNo": 860,
    "bookNo": "8",
    "title": "BI 6/596",
    "author": "DARE NOT LINGER ",
    "category": "MISSING"
  },
  {
    "serialNo": 861,
    "bookNo": "9",
    "title": "BI 7/597",
    "author": "THE UNTOLD STORY OF RANA KAPOOR ",
    "category": "MISSING"
  },
  {
    "serialNo": 862,
    "bookNo": "10",
    "title": "BI 9/599",
    "author": "AZIM PREMJI",
    "category": "MISSING"
  },
  {
    "serialNo": 863,
    "bookNo": "11",
    "title": "SHE -17/ 500",
    "author": "DO EPIC SHIT ",
    "category": "MISSING"
  },
  {
    "serialNo": 864,
    "bookNo": "12",
    "title": "Ne-4/415",
    "author": "Sputnik sweetheart",
    "category": "MISSING"
  },
  {
    "serialNo": 865,
    "bookNo": "13",
    "title": "NE-16/427",
    "author": "THE LOVELY BONES",
    "category": "MISSING"
  },
  {
    "serialNo": 866,
    "bookNo": "14",
    "title": "NE-36/437",
    "author": "One Indian girl",
    "category": "MISSING"
  },
  {
    "serialNo": 867,
    "bookNo": "15",
    "title": "NE-33/444",
    "author": "ALL THIS TIME ",
    "category": "MISSING"
  },
  {
    "serialNo": 868,
    "bookNo": "16",
    "title": "NE 59/470",
    "author": "THE GIRL ON TRAIN",
    "category": "MISSING"
  },
  {
    "serialNo": 869,
    "bookNo": "17",
    "title": "NE 61\\472",
    "author": " THE ALCHEMIST",
    "category": "MISSING"
  },
  {
    "serialNo": 870,
    "bookNo": "18",
    "title": "NE 65\\476",
    "author": "THE SECRETS YOU HIDE",
    "category": "MISSING"
  },
  {
    "serialNo": 871,
    "bookNo": "19",
    "title": "NE 71\\482",
    "author": "R.A.W.HITMAN",
    "category": "MISSING"
  },
  {
    "serialNo": 872,
    "bookNo": "20",
    "title": "S-31/638",
    "author": "മണലും പതയും",
    "category": "MISSING"
  },
  {
    "serialNo": 873,
    "bookNo": "21",
    "title": "S-27/388",
    "author": "മൈമൂന - കുട്ടികൾക്കുള്ള നോവൽ ",
    "category": "MISSING"
  },
  {
    "serialNo": 874,
    "bookNo": "22",
    "title": "S-28/391",
    "author": "വിഡ്ഢികളുടെ സ്വർഗം ",
    "category": "MISSING"
  },
  {
    "serialNo": 875,
    "bookNo": "23",
    "title": "S-19/236",
    "author": "തണ്ണീർ കുടിയന്റെ തണ്ട്",
    "category": "MISSING"
  },
  {
    "serialNo": 876,
    "bookNo": "24",
    "title": "S-11/228",
    "author": "ഓട്ടോറിക്ഷക്കാരന്റെ ഭാര്യ",
    "category": "MISSING"
  },
  {
    "serialNo": 877,
    "bookNo": "25",
    "title": "SHE-40/523",
    "author": "BOOKLESS",
    "category": "MISSING"
  },
  {
    "serialNo": 878,
    "bookNo": "26",
    "title": "SHE-44/527",
    "author": "DIFFICULT PEOPLE",
    "category": "MISSING"
  },
  {
    "serialNo": 879,
    "bookNo": "27",
    "title": "SHE-43/526",
    "author": "THE 7 HABITS OF HIGHLY EFFECTIVE PEOPLE",
    "category": "MISSING"
  },
  {
    "serialNo": 880,
    "bookNo": "28",
    "title": "ST-1/632",
    "author": "DEALING WITH DIFFICULT",
    "category": "MISSING"
  },
  {
    "serialNo": 881,
    "bookNo": "29",
    "title": "SHE 45/528",
    "author": "THE LEADER WHO HAD NO TITLE",
    "category": "MISSING"
  },
  {
    "serialNo": 882,
    "bookNo": "30",
    "title": "SHE-35/518",
    "author": "THE SEVEN HABITS OF HIGHLY EFFECTIVE PEOPLE ",
    "category": "MISSING"
  },
  {
    "serialNo": 883,
    "bookNo": "31",
    "title": "SHE 48/531",
    "author": "THE PSYCHOLOGY OF MONEY",
    "category": "MISSING"
  },
  {
    "serialNo": 884,
    "bookNo": "32",
    "title": "SHE-37/520",
    "author": "TAO:THE PATHLESS PATH",
    "category": "MISSING"
  },
  {
    "serialNo": 885,
    "bookNo": "33",
    "title": "SHE-38/521",
    "author": "MATURITY",
    "category": "MISSING"
  },
  {
    "serialNo": 886,
    "bookNo": "34",
    "title": "SHE-31/514",
    "author": "WHO SAYS YOU CANT YOU DO",
    "category": "MISSING"
  },
  {
    "serialNo": 887,
    "bookNo": "35",
    "title": "SHE-32/515",
    "author": "SENSE",
    "category": "MISSING"
  },
  {
    "serialNo": 888,
    "bookNo": "36",
    "title": "SHE 8\\491",
    "author": "WHO WILL CRY, WHEN YOU DIE",
    "category": "MISSING"
  },
  {
    "serialNo": 889,
    "bookNo": "37",
    "title": "SH-15/285",
    "author": "സ്മാർട്ട് പാരന്റിങ്",
    "category": "MISSING"
  },
  {
    "serialNo": 890,
    "bookNo": "38",
    "title": "SH-30/300",
    "author": "കാര്യവും കാരണവും",
    "category": "MISSING"
  },
  {
    "serialNo": 891,
    "bookNo": "39",
    "title": "SH-31/301",
    "author": "റിച്ച് ഡാഡ് പുവർ ഡാഡ്",
    "category": "MISSING"
  },
  {
    "serialNo": 892,
    "bookNo": "40",
    "title": "ST-5/636",
    "author": "DIGITAL MINIMALISM",
    "category": "MISSING"
  },
  {
    "serialNo": 893,
    "bookNo": "41",
    "title": "SE-17/566",
    "author": "OASIS SCORCHING SOUL",
    "category": "MISSING"
  },
  {
    "serialNo": 894,
    "bookNo": "42",
    "title": "H3/313",
    "author": "ഇന്ത്യ : അർദ്ധരാത്രി മുതൽ അര നൂറ്റാണ്ട് ",
    "category": "MISSING"
  },
  {
    "serialNo": 895,
    "bookNo": "43",
    "title": "SE-11/560",
    "author": "A THOUSAND NIGHTS",
    "category": "MISSING"
  },
  {
    "serialNo": 896,
    "bookNo": "44",
    "title": "SSE-3/623",
    "author": "THE WHISTLING SCHOOL BOY",
    "category": "MISSING"
  },
  {
    "serialNo": 897,
    "bookNo": "45",
    "title": "N-31/193",
    "author": "നാൽവർ സംഘത്തിലെ മരണകണക്ക് ",
    "category": "MISSING"
  },
  {
    "serialNo": 898,
    "bookNo": "46",
    "title": "N-7/169",
    "author": "പ്രേമലേഖനം ",
    "category": "MISSING"
  },
  {
    "serialNo": 899,
    "bookNo": "47",
    "title": "N-35/197",
    "author": "മിസ്സ്‌ ലൈല ",
    "category": "MISSING"
  },
  {
    "serialNo": 900,
    "bookNo": "48",
    "title": "S-50/386",
    "author": "അഭ്യാർത്ഥികളുടെ പൂന്തോട്ടം ",
    "category": "MISSING"
  },
  {
    "serialNo": 901,
    "bookNo": "49",
    "title": "N-10/172",
    "author": "ബാല്യകാലസഖി",
    "category": "MISSING"
  },
  {
    "serialNo": 902,
    "bookNo": "50",
    "title": "N-13/175",
    "author": "നിശബ്ദ സഞ്ചാരങ്ങൾ",
    "category": "MISSING"
  },
  {
    "serialNo": 903,
    "bookNo": "51",
    "title": "N-57/395",
    "author": "ഖബർ ",
    "category": "MISSING"
  },
  {
    "serialNo": 904,
    "bookNo": "52",
    "title": "N-16/178",
    "author": "ആൽ കെമിസ്റ്റ് ",
    "category": "MISSING"
  },
  {
    "serialNo": 905,
    "bookNo": "53",
    "title": "N-21/183",
    "author": "വൃദ്ധനും വൻകടലും ",
    "category": "MISSING"
  },
  {
    "serialNo": 906,
    "bookNo": "54",
    "title": "N-24/186",
    "author": "നാഗഫണം ",
    "category": "MISSING"
  },
  {
    "serialNo": 907,
    "bookNo": "55",
    "title": "N-19/181",
    "author": "സ്മാരക ശിലകൾ ",
    "category": "MISSING"
  },
  {
    "serialNo": 908,
    "bookNo": "56",
    "title": "N-20/182",
    "author": "ന്യൂറോ ഏരിയ ",
    "category": "MISSING"
  },
  {
    "serialNo": 909,
    "bookNo": "57",
    "title": "AB-31/357",
    "author": "കരച്ഛൻ മകൾക്കയച്ച  കത്തുകൾ ",
    "category": "MISSING"
  },
  {
    "serialNo": 910,
    "bookNo": "58",
    "title": "I-52/52",
    "author": "പുണ്യം ചെയ്ത പാത്രങ്ങൾ",
    "category": "MISSING"
  },
  {
    "serialNo": 911,
    "bookNo": "59",
    "title": "D-1/400",
    "author": "1128-ൽ ക്രൈം-27",
    "category": "MISSING"
  },
  {
    "serialNo": 912,
    "bookNo": "60",
    "title": "R-23/660",
    "author": "ANCIENT AND MEDIEVAL INDIA",
    "category": "MISSING"
  },
  {
    "serialNo": 913,
    "bookNo": "61",
    "title": "N-15/168",
    "author": "പാത്തുമ്മയുടെ ആട്",
    "category": "MISSING"
  },
  {
    "serialNo": 914,
    "bookNo": "62",
    "title": "N-32/177",
    "author": "ആടുജീവിതം",
    "category": "MISSING"
  },
  {
    "serialNo": 915,
    "bookNo": "63",
    "title": "N-54/214",
    "author": "ഒരു സങ്കീർത്തനം പോലെ",
    "category": "MISSING"
  },
  {
    "serialNo": 916,
    "bookNo": "64",
    "title": "N-55/215",
    "author": "കാവേരിയുടെ പുരുഷൻ ",
    "category": "MISSING"
  },
  {
    "serialNo": 917,
    "bookNo": "65",
    "title": "N-56/242",
    "author": "ആടുജീവിതം",
    "category": "MISSING"
  },
  {
    "serialNo": 918,
    "bookNo": "66",
    "title": "N-12/166",
    "author": "ഖസാക്കിന്റെ ഇതിഹാസം ",
    "category": "MISSING"
  },
  {
    "serialNo": 919,
    "bookNo": "67",
    "title": "g22/130",
    "author": "",
    "category": "MISSING"
  },
  {
    "serialNo": 920,
    "bookNo": "68",
    "title": "mp15/162",
    "author": "",
    "category": "MISSING"
  },
  {
    "serialNo": 921,
    "bookNo": "69",
    "title": "N-1/187",
    "author": "അന്ധർ ബധിരർ മൂക്കർ ",
    "category": "MISSING"
  },
  {
    "serialNo": 922,
    "bookNo": "70",
    "title": "258",
    "author": "ദൈവത്തിന്റെ ചാരന്മാർ",
    "category": "MISSING"
  },
  {
    "serialNo": 923,
    "bookNo": "71",
    "title": "305",
    "author": "പ്രഭാത ദീപം",
    "category": "MISSING"
  },
  {
    "serialNo": 924,
    "bookNo": "72",
    "title": "484",
    "author": "ATOMIC HABITS",
    "category": "MISSING"
  },
  {
    "serialNo": 925,
    "bookNo": "73",
    "title": "552",
    "author": "HARRYPOTTER",
    "category": "MISSING"
  },
  {
    "serialNo": 926,
    "bookNo": "74",
    "title": "600",
    "author": "THE SOUL OF THE DESERT",
    "category": "MISSING"
  },
  {
    "serialNo": 927,
    "bookNo": "75",
    "title": "682",
    "author": "INDIA AFTER GHANDI",
    "category": "MISSING"
  },
  {
    "serialNo": 928,
    "bookNo": "76",
    "title": "724",
    "author": "ബീവി ഉമ്മു സലമ(റ)",
    "category": "MISSING"
  },
  {
    "serialNo": 929,
    "bookNo": "77",
    "title": "13",
    "author": "മരണത്തിന്റെ താഴ് വരകൾ",
    "category": "MISSING"
  },
  {
    "serialNo": 930,
    "bookNo": "78",
    "title": "",
    "author": "നിങ്ങളുടെ പ്രവാചകന്‍\n",
    "category": "MISSING"
  }
];